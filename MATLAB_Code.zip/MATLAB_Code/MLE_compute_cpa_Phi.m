function [Phi_T,Phi_B,Phi_R] = MLE_compute_cpa_Phi(Rpos,Rvel,Racc)
%------------------------------------------------------------------------------------------------------------------------
%   This subroutine computes the Phi matrices numerically for CPA time,
%   bearing and range so that standard deviations can be computed.
%------------------------------------------------------------------------------------------------------------------------
% Inputs:
%   Rpos - relative  x, y, z   position         (m)             [ 1 x 3 ]
%   Rvel - relative  x, y, z   velocity         (m/s)           [ 1 x 3 ]
%   Racc - relative  x, y, z acceleration       (m/s2)          [ 1 x 3 ]
%------------------------------------------------------------------------------------------------------------------------
% Outputs:
%   Phi_T -  Phi matrix for CPA time
%   Phi_B -  Phi matrix for CPA bearing
%   Phi_R -  Phi matrix for CPA range
%------------------------------------------------------------------------------------------------------------------------

% Initialization
del_pos  = 0.100;
del_vel  = 0.010;
del_acc  = 0.001;
Phi_T    = zeros(1,6);
Phi_B    = zeros(1,6);
Phi_R    = zeros(1,6);

[Tcpa1,Bcpa1,Rcpa1] = MLE_compute_cpa_acc(Rpos,Rvel,Racc);

%------------------------------------------------------------------------------------------------------------------------
% Tcpa partials with respect to xrel, yrel, xdot, ydot, xacc, yacc
[Tcpa2,Bcpa2,Rcpa2] = MLE_compute_cpa_acc(Rpos+[ del_pos 0 0 ],Rvel,Racc);
Phi_T(1,1) = (Tcpa2 - Tcpa1) / del_pos; % dTcpa_dxpos
[Tcpa2,Bcpa2,Rcpa2] = MLE_compute_cpa_acc(Rpos+[ 0 del_pos 0 ],Rvel,Racc);
Phi_T(1,2) = (Tcpa2 - Tcpa1) / del_pos; % dTcpa_dypos
[Tcpa2,Bcpa2,Rcpa2] = MLE_compute_cpa_acc(Rpos,Rvel+[ del_vel 0 0 ],Racc);
Phi_T(1,3) = (Tcpa2 - Tcpa1) / del_vel; % dTcpa_dxvel
[Tcpa2,Bcpa2,Rcpa2] = MLE_compute_cpa_acc(Rpos,Rvel+[ 0 del_vel 0 ],Racc);
Phi_T(1,4) = (Tcpa2 - Tcpa1) / del_vel; % dTcpa_dyvel
if norm(Racc) > 0
   [Tcpa2,Bcpa2,Rcpa2] = MLE_compute_cpa_acc(Rpos,Rvel,Racc+[ del_acc 0 0 ]);
   Phi_T(1,5) = (Tcpa2 - Tcpa1) / del_acc; % dTcpa_dxacc
   [Tcpa2,Bcpa2,Rcpa2] = MLE_compute_cpa_acc(Rpos,Rvel,Racc+[ 0 del_acc 0 ]);
   Phi_T(1,6) = (Tcpa2 - Tcpa1) / del_acc; % dTcpa_dyacc
end

%------------------------------------------------------------------------------------------------------------------------
% Compute CPA positions
Tcpa = Tcpa1;
xrc  = Rpos(1) + Rvel(1)*Tcpa + Racc(1)*Tcpa^2/2;
yrc  = Rpos(2) + Rvel(2)*Tcpa + Racc(2)*Tcpa^2/2;
Rcpa = sqrt(xrc*xrc + yrc*yrc);

%------------------------------------------------------------------------------------------------------------------------
% Bcpa partials with respect to xrel, yrel, xdot, ydot, xacc, yacc
Phi_B(1,1) =  yrc/Rcpa^2;
Phi_B(1,2) = -xrc/Rcpa^2;
Phi_B(1,3) = Phi_B(1,1)*Tcpa;
Phi_B(1,4) = Phi_B(1,2)*Tcpa;
if norm(Racc) > 0
   Phi_B(1,5) = Phi_B(1,1)*Tcpa^2/2;
   Phi_B(1,6) = Phi_B(1,2)*Tcpa^2/2;
end

%------------------------------------------------------------------------------------------------------------------------
% Rcpa partials with respect to xrel, yrel, xdot, ydot, xacc, yacc
Phi_R(1,1) =  xrc/Rcpa;
Phi_R(1,2) =  yrc/Rcpa;
Phi_R(1,3) = Phi_R(1,1)*Tcpa;
Phi_R(1,4) = Phi_R(1,2)*Tcpa;
if norm(Racc) > 0
   Phi_R(1,5) = Phi_R(1,1)*Tcpa^2/2;
   Phi_R(1,6) = Phi_R(1,2)*Tcpa^2/2;
end

%------------------------------------------------------------------------------------------------------------------------
return;
