function [x1,x2,x3,nr,dis] = solve_cubic_cpa(a,b,c)
%------------------------------------------------------------------------------------------------------------------------
%   This subroutine finds the "nr" real roots (nr = 1,2,3) of the cubic
%   equation f(x) = x**3 + a*x**2 + b*x + c = 0.  There can be one real root
%   and one pair of comlex roots, three real roots with at least two equal
%   roots or three distinct roots.
%   Reference:  "Numerical Recipes", William H. Press et. al.,
%               Cambridge University Press, Cambridge, 1986, pags 145-146
%------------------------------------------------------------------------------------------------------------------------

% set number of roots and roots to zero
nr = 0;
x1 = 0.0;
x2 = 0.0;
x3 = 0.0;
x  = zeros(3,1);

% find the roots
q   = (a*a-3.0*b)/9.0;
r   = (2.0*a*a*a-9.0*a*b+27.0*c)/54.0;
q3  = q*q*q;
r2  = r*r;
dis = q3-r2;
if dis < 0.0
   % one distinct real root
   nr    = 1;
   signr = +1.0;
   if r < 0.0
      signr = -1.0;
   end
   xyz   = (sqrt(r2-q3) + abs(r))^(1/3);
   x1    = -signr*(xyz + q/xyz) - a/3.0;
   x(1)  = x1;
else
   % up to three distinct real roots
   nr = 3;
   t  = 0.0;
   if q3 > 0.0
      ratio = r/sqrt(q3);
      if abs(ratio) <= 1.0
         t = acos(r/sqrt(q3));
      end
   end
   if q >= 0.0
      xyz = -2.0*sqrt(q);
   else
      xyz = 0.0;
   end
   x1 = xyz*cos(        t       /3.0) - a/3.0;
   x2 = xyz*cos((t + 2*pi)/3.0) - a/3.0;
   x3 = xyz*cos((t + 4*pi)/3.0) - a/3.0;
end

%------------------------------------------------------------------------------------------------------------------------
return;
