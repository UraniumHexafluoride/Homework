function [CPA_time,CPA_brg,CPA_rng,CPA_time_std,CPA_brg_std,CPA_rng_std] = ...
         MLE_compute_cpa_2D_PVA(Rpos,Rvel,Racc,Phat)
%------------------------------------------------------------------------------------------------------------------------
%   This function computes 2D Closest-Point-of-Approach (CPA) parameters
%   and standard deviations for an accelerating sensor/target scenario.
%------------------------------------------------------------------------------------------------------------------------
% Inputs:
%   Rpos - relative  x, y, z position       (m)             [ 1 x 3 ]
%   Rvel - relative  x, y, z velocity       (m/s)           [ 1 x 3 ]
%   Racc - relative  x, y, z acceleration   (m/s^2)         [ 1 x 3 ]
%   Phat - relative state covariance matrix                 [ 6 x 6 ]
%------------------------------------------------------------------------------------------------------------------------
% Outputs:
%   CPA_time     - time to CPA                              (sec)
%   CPA_brg      - bearing at CPA                           (rad)
%   CPA_rng      - range at CPA                             (m)
%   CPA_time_std - time to CPA standard deviation           (sec)
%   CPA_brg_std  - bearing at CPA standard deviation        (rad)
%   CPA_rng_std  - range at CPA standard deviation          (m)
%------------------------------------------------------------------------------------------------------------------------

% Compute CPA time, bearing, and range
[CPA_time,CPA_brg,CPA_rng] = MLE_compute_cpa_acc(Rpos,Rvel,Racc);

% Compute numerical sensitivity / Jacobian matrices
[Phi_T,Phi_B,Phi_R]        = MLE_compute_cpa_Phi(Rpos,Rvel,Racc);

% Compute parameter standard deviations
CPA_time_std = sqrt(Phi_T*Phat*Phi_T');
CPA_brg_std  = sqrt(Phi_B*Phat*Phi_B');
CPA_rng_std  = sqrt(Phi_R*Phat*Phi_R');

return;
