function [Tcpa,Bcpa,Rcpa,Tcpa_std,Bcpa_std,Rcpa_std,Xtgt_cpa,Ytgt_cpa] = ...
         MLE_compute_cpa_2D_PV(Spos,Svel,Tpos,Tvel,Phat,plot_flag)
%------------------------------------------------------------------------------------------------------------------------
%   This function computes 2D Closest-Point-of-Approach (CPA) parameters
%   based on constant velocity sensor and contact trajectories along with
%   their standard deviations.
%------------------------------------------------------------------------------------------------------------------------
% Inputs
%   Spos     - sensor position     [ xpos ypos ]           (m)
%   Svel     - sensor velocity     [ xdot ydot ]           (m/s)
%   Tpos     - contact position    [ xpos ypos ]           (m)
%   Tvel     - contact velocity    [ xdot ydot ]           (m/s)
%   Phat     - covariance matrix   [ xpos ypos xdot ydot ] (m,m,m/s,m/s )
%------------------------------------------------------------------------------------------------------------------------
% Outputs
%   Tcpa     - time to CPA                                 (sec)
%   Bcpa     - bearing at CPA                              (rad)
%   Rcpa     - range at CPA                                (m)
%   Tcpa_std - time to CPA standard deviation              (sec)
%   Bcpa_std - bearing at CPA standard deviation           (rad)
%   Rcpa_std - range at CPA standard deviation             (m)
%   Xtgt_cpa - contact x position at CPA                   (m)
%   Ytgt_cpa - contact y position at CPA                   (m)
%------------------------------------------------------------------------------------------------------------------------

% Initialization
if nargin == 5
   plot_flag = ~true;
end
Tcpa     = [];
Bcpa     = [];
Rcpa     = [];
Tcpa_std = [];
Bcpa_std = [];
Rcpa_std = [];
Xtgt_cpa = [];
Ytgt_cpa = [];

%------------------------------------------------------------------------------------------------------------------------
% Compute CPA parameters
xr       = Tpos(1) - Spos(1);
yr       = Tpos(2) - Spos(2);
xrd      = Tvel(1) - Svel(1);
yrd      = Tvel(2) - Svel(2);
rvel     = sqrt(xrd*xrd + yrd*yrd);
rvel2    =      xrd*xrd + yrd*yrd;

if norm(rvel) == 0
   % CPA is at current time and constant
   Tcpa = 0.0;
else
   % CPA in future or past
   Tcpa = -(xr*xrd + yr*yrd)/rvel2;
end
if abs(Tcpa) > 2*60*60
   % Do not consider CPAs more than 2 hours in past or future
   Tcpa = [];
   return;
end
xrc      = xr + xrd*Tcpa;
yrc      = yr + yrd*Tcpa;
Bcpa     = taninv(xrc,yrc);
Rcpa     = sqrt(xrc*xrc + yrc*yrc);

Xtgt_cpa = Tpos(1) + Tvel(1)*Tcpa;
Ytgt_cpa = Tpos(2) + Tvel(2)*Tcpa;

%------------------------------------------------------------------------------------------------------------------------
% Compute CPA parameter standard deviations
N        = -(xr*xrd + yr*yrd);
Phi(1,1) = -xrd/rvel2;
Phi(1,2) = -yrd/rvel2;
Phi(1,3) = (-xr*rvel2 -2*N*xrd) / rvel2^2;
Phi(1,4) = (-yr*rvel2 -2*N*yrd) / rvel2^2;
%prt_rmtx(1,Phi,'CV Phi_T');
Tcpa_std = sqrt(Phi*Phat*Phi');
if Tcpa_std > 3600
   Tcpa_std = 3600;
end

Phi(1,1) =  yrc/Rcpa^2;
Phi(1,2) = -xrc/Rcpa^2;
Phi(1,3) = Phi(1,1)*Tcpa;
Phi(1,4) = Phi(1,2)*Tcpa;
%prt_rmtx(1,Phi,'CV Phi_B');
Bcpa_std = sqrt(Phi*Phat*Phi');
if Bcpa_std > pi/2
   Bcpa_std = pi/2;
end

Phi(1,1) =  xrc/Rcpa;
Phi(1,2) =  yrc/Rcpa;
Phi(1,3) = Phi(1,1)*Tcpa;
Phi(1,4) = Phi(1,2)*Tcpa;
%prt_rmtx(1,Phi,'CV Phi_R');
Rcpa_std = sqrt(Phi*Phat*Phi');
if Rcpa_std > 10000
   Rcpa_std = 10000;
end

%------------------------------------------------------------------------------------------------------------------------
% Plot the scenario
if plot_flag
   define_colors;
   Spos_cpa = Spos + Svel*Tcpa;
   Tpos_cpa = Tpos + Tvel*Tcpa;
   summary1 = {[' time to CPA: ' num2str(Tcpa/60,'%6.2f')     ' min' ], ...
               ['  Brg at CPA: ' num2str(Bcpa*180/pi,'%6.2f') '^o '  ], ...
               ['  Rng at CPA: ' num2str(Rcpa/1000,'%6.3f')   ' Km'  ]};
   fctr = 1.0/1000;
   figure;
   hold on;
   % sensor
   plot(Spos(1)*fctr,Spos(2)*fctr,'linestyle','none','marker','o', ...
        'markersize',8,'markeredgecolor','k','markerfacecolor',slate);
   plot([Spos(1) Spos_cpa(1)]*fctr,[Spos(2),Spos_cpa(2)]*fctr, ...
        'linestyle','--','linewidth',2,'color',slate);
   plot(Spos_cpa(1)*fctr,Spos_cpa(2)*fctr,'linestyle','none', ...
        'marker','o','markersize',8,'markeredgecolor','k', ...
        'markerfacecolor',purple);
   text(Spos(1)*fctr,Spos(2)*fctr,'  sensor','Fontsize',10, ...
        'Fontweight','bold','color',slate);
   % contact
   plot(Tpos(1)*fctr,Tpos(2)*fctr,'linestyle','none','marker','o', ...
        'markersize',8,'markeredgecolor','k','markerfacecolor',olive);
   plot([Tpos(1) Tpos_cpa(1)]*fctr,[Tpos(2),Tpos_cpa(2)]*fctr, ...
        'linestyle','--','linewidth',2,'color',olive);
   plot(Tpos_cpa(1)*fctr,Tpos_cpa(2)*fctr,'linestyle','none', ...
        'marker','o','markersize',8,'markeredgecolor','k','markerfacecolor',purple);
   text(Tpos(1)*fctr,Tpos(2)*fctr,'  contact    ', ...
        'Fontsize',10,'Fontweight','bold','color',olive);
   % CPA
   plot([Spos_cpa(1) Tpos_cpa(1)]*fctr,[Spos_cpa(2) Tpos_cpa(2)]*fctr, ...
        'linestyle','-','linewidth',2,'color',purple);
   xcpa = (Spos_cpa(1) + Tpos_cpa(1)) / 2;
   ycpa = (Spos_cpa(2) + Tpos_cpa(2)) / 2;
   text(xcpa*fctr,ycpa*fctr,' CPA','Fontsize',10,'Fontweight','bold','color',purple);
   % label the plot
   axis equal;
   ax   = axis;
   xtxt = ax(1) + .05*(ax(2)-ax(1));
   ytxt = ax(4) - .10*(ax(4)-ax(3));
   text(xtxt,ytxt,summary1,'Fontsize',10,'Fontweight','bold', ...
        'Fontname','Courier New');
   xlabel('X Position','Fontsize',12,'Fontweight','bold');
   ylabel('Y Position','Fontsize',12,'Fontweight','bold');
   title('CPA Computations - 2D','Fontsize',12,'Fontweight','bold');
   box on;
end

%------------------------------------------------------------------------------------------------------------------------
return;
