function expand_scale(Pct)
%------------------------------------------------------------------------------------------------------------------------
%   This function expands the current plot scale by "Pct" per cent up to
%   100%.  Note: 0 <= Pct <= 100.
%------------------------------------------------------------------------------------------------------------------------

if Pct > 100
   Pct = 100;
end
pct    = abs(Pct)/100;
ax_dum = axis;
del_x  = ax_dum(2) - ax_dum(1);
del_y  = ax_dum(4) - ax_dum(3);
ax(1)  = ax_dum(1) - pct*del_x;
ax(2)  = ax_dum(2) + pct*del_x;
ax(3)  = ax_dum(3) - pct*del_y;
ax(4)  = ax_dum(4) + pct*del_y;
axis(ax);

return;
