% Constants
pi     = 3.14159265358979;      %  pi
pi2    = 2*pi;                  % 2 pi
dtr    = pi/180.0;              % degrees to  radians conversion factor
rtd    = 1.0/dtr;               % radians to  degrees conversion factor
cftty  = 1.0/3.0;               %  feet to yards conversion
cytft  = 1.0/cftty;             % yards to  feet conversion
cytm   = .9144;                 % yards to meters conversion factor
cmty   = 1.0/cytm;              % meters to yards conversion factor
cmtft  = 3.2808;                % meters to feet  conversion factor
cfttm  = 1.0/cmtft;             % feet to meters  conversion factor
cnmty  = 2025.3718285;          % nautical miles to yards conversion factor
cytnm  = 1.0/cnmty;             % yards to nautical miles conversion factor
cnmtm  = 1852.0;                % nautical miles to meters conversion factor
cmtnm  = 1.0/cnmtm;             % meters to nautical miles conversion factor
cystk  = 1.77745;               % yds/sec to knots   conversion factor
cktys  = 1.0/cystk;             % knots to yds/sec   conversion factor
cktfs  = cktys*cytft;           % knots to ft/sec    conversion factor
cfstk  = 1.0/cktfs;             % ft/sec to knots    conversion factor
cnmtft = 6076.1154855;          % nautical miles to feet conversion factor
cfttnm = 1.0/cnmtft;            % feet to nautical miles conversion factor
cktms  = cktys*cytm;            % knots to meters/sec conversion factor
cmstk  = 1.0/cktms;             % meters/sec to knots conversion factor
cmtin  = cmtft*12;              % meters to inches conversion
cintm  = 1.0/cmtin;             % inches to meters conversion
cintmm = 1000.0/cmtin;          % inches to millimeters conversion
cmmtin = cmtin/1000.0;          % millimeters to inches conversion
cKmtsm = 1000*cmtft/5280;       % kilometers to statute miles
cKmtnm = 1000*cmtft/cnmtft;     % kilometers to statute miles

% Notes
% sound intensity              W/m2
% sound pressure               Pa
% Watt                         1 joule/sec,   1 kg m2/s3
% volt    potential difference 1V = 1W/A      V = IR    water pressure
