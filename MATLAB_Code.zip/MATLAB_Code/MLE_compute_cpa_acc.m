function [CPA_time,CPA_brg,CPA_rng] = MLE_compute_cpa_acc(Rpos,Rvel,Racc)
%------------------------------------------------------------------------------------------------------------------------
%   This function computes 3D CPA parameters given an accelerating sensor
%   and an accelerating contact.
%------------------------------------------------------------------------------------------------------------------------
% Inputs:
%   Rpos - relative  x, y, z   position         (m)             [ 1 x 3 ]
%   Rvel - relative  x, y, z   velocity         (m/s)           [ 1 x 3 ]
%   Racc - relative  x, y, z acceleration       (m/s2)          [ 1 x 3 ]
%------------------------------------------------------------------------------------------------------------------------
% Outputs:
%   CPA_time -      time  at CPA                (sec)
%   CPA_brg  -   bearing  at CPA                (rad)
%   CPA_rng  -  2D range  at CPA                (m)
%------------------------------------------------------------------------------------------------------------------------

% Initialization
CPA_time   = [];
CPA_brg    = [];
CPA_rng    = [];

%------------------------------------------------------------------------------------------------------------------------
% Compute CPA parameters
dnom = Racc*Racc';
if dnom == 0
   % No acceleration
   Tcpa  = -(Rpos*Rvel')/(Rvel*Rvel');
   indxG = [ 1 ];
elseif dnom > 0
   % Non-zero acceleration
   [x1,x2,x3,nr,dis] = ...
       solve_cubic_cpa(3*Rvel*Racc'/dnom,2*(Rpos*Racc'+Rvel*Rvel')/dnom,2*Rpos*Rvel'/dnom);
   Tcpa  = sort(unique([ x1 x2 x3 ]'),'ascend');
   indxG = [ 1:nr ];
end

%------------------------------------------------------------------------------------------------------------------------
% Check second derivative to verify minimum range
Ncpa = 0;
if ~isempty(indxG)
   for kk = 1:length(indxG)
       dum_time = Tcpa(indxG(kk));
       dum_Rpos = [ Rpos(1) + Rvel(1)*dum_time + Racc(1)*dum_time.^2/2 ...
                    Rpos(2) + Rvel(2)*dum_time + Racc(2)*dum_time.^2/2 ...
                    Rpos(3) + Rvel(3)*dum_time + Racc(3)*dum_time.^2/2 ];
       dum_Rvel = [ Rvel(1) + Racc(1)*dum_time ...
                    Rvel(2) + Racc(2)*dum_time ...
                    Rvel(3) + Racc(3)*dum_time ];
       dum_Racc = Racc;
       RSddotN  = dum_Rvel*dum_Rvel' + dum_Rpos*dum_Racc';
       if RSddotN > 0
          % Minimum range point
          valid             = true;
          Ncpa              = Ncpa + 1;
          CPA_time(Ncpa)    = dum_time;
          CPA_brg(Ncpa)     = taninv(dum_Rpos(1),dum_Rpos(2));
          CPA_rng(Ncpa)     = norm([dum_Rpos(1:2)]);
       end
   end
end

%------------------------------------------------------------------------------------------------------------------------
% For multiple CPAs, keep the one with minimum future or past time
if Ncpa > 1
   indxN = find(CPA_time < 0);
   if ~isempty(indxN)
      indxK = indxN(end);
   end
   indxP = find(CPA_time > 0);
   if ~isempty(indxP)
      indxK = indxP(1);
   end
   CPA_time = CPA_time(indxK);
   CPA_brg  = CPA_brg(indxK);
   CPA_rng  = CPA_rng(indxK);
end

%------------------------------------------------------------------------------------------------------------------------
return;
