% DRAW_ARROWHEAD Draws a solid 2D arrow head into current plot.
%
%   DRAW_ARROWHEAD(x,y,clr,ArSize,Where) draws an arrow head into current plot.
%   Adapted from arrowh by Florian Knorn.

function handle = draw_arrowhead(x,y,clr,ArSize,Where)

%-- errors
if nargin < 2
   return;
end
if length(x) < 2 || length(y) < 2
   return;
end
if (x(1) == x(2)) && (y(1) == y(2))
   return;
end
if nargin <= 2
   clr = 'b';
end
if nargin <= 3
   ArSize = [100,100];
end

handle = [];

%-- check if variables left empty, deal width ArSize and Color
if isempty(clr)
   clr = 'b'; nonsolid = false;
elseif ischar(clr)
   if strncmp('e',clr,1) % for non-solid arrow heads
      nonsolid = true; clr = clr(2);
   else
      nonsolid = false;
   end
elseif isvector(clr)
   if length(clr) == 4 && clr(1) == 0 % for non-solid arrow heads
      nonsolid = true;
      clr = clr(2:end);
   else
      nonsolid = false;
   end
else
   error('COLOR argument of wrong type (must be either char or vector)');
end

if nargin <= 4
   if (length(x) == length(y)) && (length(x) == 2)
      Where = 100;
   else
      Where = 50;
   end
end

if isempty(ArSize)
   ArSize = [100,100];
end
if length(ArSize) == 2
   ArWidth = 0.75*ArSize(2)/100; % .75 to make arrows it a bit slimmer
else
   ArWidth = 0.75;
end
ArSize = ArSize(1);

%-- determine and remember the hold status, toggle if necessary
if ishold
   WasHold = 1;
else
   WasHold = 0;
   hold on;
end

%-- start for-loop in case several arrows are wanted
for Loop = 1:length(Where)
   %-- if vectors "longer" then 2 are given we're dealing with time series
   if (length(x) == length(y)) && (length(x) > 2)
      j = floor(length(x)*Where(Loop)/100); %-- determine that location
      if j >= length(x), j = length(x) - 1; end
      if j == 0, j = 1; end
      x1 = x(j); x2 = x(j+1); y1 = y(j); y2 = y(j+1);
   else %-- just two points given - take those
      x1 = x(1); x2 = (1-Where/100)*x(1)+Where/100*x(2);
      y1 = y(1); y2 = (1-Where/100)*y(1)+Where/100*y(2);
   end

   %-- get axe ranges and their norm
   OriginalAxis = axis;
   Xextend = abs(OriginalAxis(2)-OriginalAxis(1));
   Yextend = abs(OriginalAxis(4)-OriginalAxis(3));

   %-- determine angle for the rotation of the triangle
   if x2 == x1 %-- line vertical, no need to calculate slope
      if y2 > y1
         p = pi/2;
      else
         p = -pi/2;
      end
   else %-- line not vertical, go ahead and calculate slope
      %-- using normed differences (looks better like that)
      m = ( (y2 - y1)/Yextend ) / ( (x2 - x1)/Xextend );
      if x2 > x1 %-- now calculate the resulting angle
         p = atan(m);
      else
         p = atan(m) + pi;
      end
   end

   %-- the arrow is made of a transformed "template triangle".
   %-- the template triangle (it points "east", centered in (0,0)):
   xt = [1 -sin(pi/6) -sin(pi/6)];
   yt = ArWidth*[0 cos(pi/6) -cos(pi/6)];

   %-- rotate it by the angle determined above:
   xd = []; yd = [];
   for i=1:3
       xd(i) = cos(p)*xt(i) - sin(p)*yt(i);
       yd(i) = sin(p)*xt(i) + cos(p)*yt(i);
   end

   %-- move the triangle so that its "head" lays in (0,0):
   xd = xd - cos(p);
   yd = yd - sin(p);

   %-- stretch/deform the triangle to look good on the current axes:
   xd = xd*Xextend*ArSize/10000;
   yd = yd*Yextend*ArSize/10000;

   %-- move the triangle to the location where it's needed
   xd = xd + x2;
   yd = yd + y2;

   %-- draw the actual triangle
   handle(Loop) = patch(xd,yd,clr,'EdgeColor',clr);
   if nonsolid, set(handle(Loop),'facecolor','none'); end
end % Loops

%-- restore original axe ranges and hold status
axis(OriginalAxis);
if ~WasHold
   hold off
end

%-- work done, good bye.
