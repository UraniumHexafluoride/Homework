function [] = draw_cpa_cone_CC(xs,ys,rng,brg,rng_std,brg_std,cone_color)
%------------------------------------------------------------------------------------------------------------------------
%   This function draws the CPA prediction cone on the current plot.
%   Note: The current plot is assumed to be in Km.
%------------------------------------------------------------------------------------------------------------------------
% Inputs:
%      xs       - x position of sensor          (m)
%      ys       - y position of sensor          (m)
%      rng      - CPA range                     (m)
%      brg      - CPA bearing                   (rad)
%      rng_std  - CPA range  standard deviation (m)
%      brg_std  - CPA bearing standard deviation (rad)
%------------------------------------------------------------------------------------------------------------------------

% Initialization
define_colors;
Lstyle    = '--';
Lwidth    = 2;
Nsig      = 1.0;

if brg_std > 30.0*pi/180
   % Do not plot huge CPA cones
   return;
end

%------------------------------------------------------------------------------------------------------------------------
% Plot the cone
angmin = addrad(brg,-Nsig*brg_std);
angmax = addrad(brg,+Nsig*brg_std);
if angmin > angmax
   angmin = angmin - 2*pi;
end
trubrg = linspace(angmin,angmax,20);
xc     = xs + (rng+Nsig*rng_std)*sin(trubrg);
yc     = ys + (rng+Nsig*rng_std)*cos(trubrg);
plot([xs xc( 1 )],[ys yc( 1 )],'linestyle',Lstyle, ...
     'linewidth',Lwidth,'color',cone_color);
plot(xc,yc,'linestyle',Lstyle,'linewidth',Lwidth,'color',cone_color);
plot([xs xc(end)],[ys yc(end)],'linestyle',Lstyle, ...
     'linewidth',Lwidth,'color',cone_color);
xc     = xs + (rng-Nsig*rng_std)*sin(trubrg);
yc     = ys + (rng-Nsig*rng_std)*cos(trubrg);
plot(xc,yc,'linestyle',Lstyle,'linewidth',Lwidth,'color',cone_color);

%------------------------------------------------------------------------------------------------------------------------
return;
