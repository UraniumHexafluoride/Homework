function [xclose,indx] = find_closest(Xarr,xval)
%------------------------------------------------------------------------------------------------------------------------
%   This function finds the closest value to "xval" in the array "Xarr".
%   The index to the closest value is also returned.
%------------------------------------------------------------------------------------------------------------------------

indx   = find(abs(Xarr-xval) == min(abs(Xarr-xval)), 1 );
xclose = Xarr(indx);

return;
