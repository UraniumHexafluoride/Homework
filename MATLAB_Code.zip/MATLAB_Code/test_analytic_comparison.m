% Test analytic partials vs numerical partials in MLE_compute_cpa_Phi
clearvars;
close all;

define_constants;
define_colors;

% Acceleration test case from Test_MLE_compute_CPA
Spos = [     0        0      0 ];
Svel = [ 3.000   -1.000      0 ];
Tpos = [ 10000    -5000      0 ];
Tvel = [ 3.000    4.000      0 ];
Sacc = [ +0.002 +0.003     0 ];
Tacc = [ -0.005  0.005     0 ];

Rpos = Tpos - Spos;
Rvel = Tvel - Svel;
Racc = Tacc - Sacc;

Phat = diag([ 100.0^2 100.0^2  0.1^2  0.1^2 .001^2 .001^2 ]);

% 1. Numerical partials from Old routine
[Phi_T_num, Phi_B_num, Phi_R_num] = MLE_compute_cpa_Phi(Rpos, Rvel, Racc);
[Tcpa, Bcpa, Rcpa] = MLE_compute_cpa_acc(Rpos, Rvel, Racc);

% 2. Analytic partials via Implicit Function Theorem
% r(t) = Rpos + Rvel*t + 0.5*Racc*t^2
% v(t) = Rvel + Racc*t
rc = Rpos + Rvel*Tcpa + 0.5*Racc*Tcpa^2;
vc = Rvel + Racc*Tcpa;

% Second derivative of 0.5*R^2(t): d/dt (r.v) = ||v||^2 + r.a
D = vc*vc' + rc*Racc'; % Scalar denominator > 0

% Partial of F = r.v with respect to state [x0, y0, vx0, vy0, ax0, ay0]
% dF/dr0 = v
% dF/dv0 = t*v + r
% dF/da0 = 0.5*t^2*v + t*r
% Since F(Tcpa, x) = 0, dTcpa/dx = - (dF/dx) / (dF/dt) = - (dF/dx) / D

Phi_T_ana = zeros(1, 6);
Phi_T_ana(1, 1:2) = -vc(1:2) / D;
Phi_T_ana(1, 3:4) = -(Tcpa*vc(1:2) + rc(1:2)) / D;
Phi_T_ana(1, 5:6) = -(0.5*Tcpa^2*vc(1:2) + Tcpa*rc(1:2)) / D;

% Range partials
Rcpa_calc = sqrt(rc(1)^2 + rc(2)^2);
Phi_R_ana = zeros(1, 6);
Phi_R_ana(1, 1) = rc(1)/Rcpa_calc;
Phi_R_ana(1, 2) = rc(2)/Rcpa_calc;
Phi_R_ana(1, 3) = Phi_R_ana(1, 1)*Tcpa;
Phi_R_ana(1, 4) = Phi_R_ana(1, 2)*Tcpa;
Phi_R_ana(1, 5) = Phi_R_ana(1, 1)*Tcpa^2/2;
Phi_R_ana(1, 6) = Phi_R_ana(1, 2)*Tcpa^2/2;

% Bearing partials
% B = atan2(rc(1), rc(2))
% dB/dx = (rc(2)*drc(1)/dx - rc(1)*drc(2)/dx) / Rcpa^2
% where drc/dx = drc/dx_explicit + vc * dTcpa/dx
dB_drc = [rc(2), -rc(1)] / Rcpa_calc^2;
drc_dx = zeros(2, 6);
drc_dx(1:2, 1:2) = eye(2);
drc_dx(1:2, 3:4) = Tcpa * eye(2);
drc_dx(1:2, 5:6) = 0.5 * Tcpa^2 * eye(2);
% Total derivative of rc with respect to state:
drc_total = drc_dx + vc(1:2)' * Phi_T_ana;
Phi_B_ana = dB_drc * drc_total;

% Standard deviations
std_T_num = sqrt(Phi_T_num * Phat * Phi_T_num');
std_T_ana = sqrt(Phi_T_ana * Phat * Phi_T_ana');

std_B_num = sqrt(Phi_B_num * Phat * Phi_B_num');
std_B_ana = sqrt(Phi_B_ana * Phat * Phi_B_ana');

std_R_num = sqrt(Phi_R_num * Phat * Phi_R_num');
std_R_ana = sqrt(Phi_R_ana * Phat * Phi_R_ana');

fprintf('=== COMPARISON OF NUMERICAL VS ANALYTIC PARTIALS ===\n\n');
fprintf('Phi_T (Numerical): %10.5f %10.5f %10.5f %10.5f %10.5f %10.5f\n', Phi_T_num);
fprintf('Phi_T (Analytic):  %10.5f %10.5f %10.5f %10.5f %10.5f %10.5f\n', Phi_T_ana);
fprintf('Time Std Dev:      Numerical = %8.4f min,  Analytic = %8.4f min\n\n', std_T_num/60, std_T_ana/60);

fprintf('Phi_R (Numerical): %10.5f %10.5f %10.5f %10.5f %10.5f %10.5f\n', Phi_R_num);
fprintf('Phi_R (Analytic):  %10.5f %10.5f %10.5f %10.5f %10.5f %10.5f\n', Phi_R_ana);
fprintf('Range Std Dev:     Numerical = %8.4f Km,   Analytic = %8.4f Km\n\n', std_R_num/1000, std_R_ana/1000);

fprintf('Phi_B (Old formula): %10.5f %10.5f %10.5f %10.5f %10.5f %10.5f\n', Phi_B_num);
fprintf('Phi_B (Full chain):  %10.5f %10.5f %10.5f %10.5f %10.5f %10.5f\n', Phi_B_ana);
fprintf('Bearing Std Dev:   Old = %8.4f deg,  Full Chain = %8.4f deg\n', std_B_num*rtd, std_B_ana*rtd);
