% Test_MLE_compute_CPA
%------------------------------------------------------------------------------------------------------------------------
%   This program computes the CPA time, range and bearing as well as their
% standard deviations for the constant velocity and constant acceleration
% cases.
%------------------------------------------------------------------------------------------------------------------------
clearvars;
close all;
fclose all;

%------------------------------------------------------------------------------------------------------------------------
% Restore path
restoredefaultpath;

%------------------------------------------------------------------------------------------------------------------------
% Initialization
define_colors;
define_constants;
Tdur   =  1800.0;                       % scenario duration                    (sec)
Tinc   =     1.0;                       % time increment                       (sec)
Tics   =   5.0*60;                      % tick marks on geographic plot        (sec)
fctr   =   1/1000;                      % meters to Km conversion              (--)
Test   =        2;                      % Test type
                                        %   1 = constant velocity
                                        %   2 = constant acceleration
Spos   = [     0        0      0 ];     % sensor position             [ x y z ] (m)
Svel   = [ 3.000   -1.000      0 ];     % sensor velocity             [ x y z ] (m/s)
Tpos   = [ 10000    -5000      0 ];     % target position             [ x y z ] (m)
Tvel   = [ 3.000    4.000      0 ];     % target velocity             [ x y z ] (m/s)
if    Test == 1
    Sacc = [  0.000  0.000     0 ];     % sensor acceleration         [ x y z ] (m/s^2)
    Tacc = [  0.000  0.000     0 ];     % target acceleration         [ x y z ] (m/s^2)
elseif Test == 2
    Sacc = [ +0.002 +0.003     0 ];     % sensor acceleration         [ x y z ] (m/s^2)
    Tacc = [ -0.005  0.005     0 ];     % target acceleration         [ x y z ] (m/s^2)
end

time = 0.0 : Tinc : Tdur;
MLE_parms.dbug_flag =  true;
MLE_parms.plot_flag = ~true;

%------------------------------------------------------------------------------------------------------------------------
% Compute sensor trajectory
sen_xpos = Spos(1) + Svel(1)*time + (1/2)*Sacc(1)*time.^2;
sen_ypos = Spos(2) + Svel(2)*time + (1/2)*Sacc(2)*time.^2;
sen_zpos = Spos(3) + Svel(3)*time + (1/2)*Sacc(3)*time.^2;
sen_xvel = Svel(1) + Sacc(1)*time;
sen_yvel = Svel(2) + Sacc(2)*time;
sen_zvel = Svel(3) + Sacc(3)*time;
sen_xacc = Sacc(1)*ones(size(time));
sen_yacc = Sacc(2)*ones(size(time));
sen_zacc = Sacc(3)*ones(size(time));
sen_spd  = sqrt(sen_xvel.^2 + sen_yvel.^2 + sen_zvel.^2);

%------------------------------------------------------------------------------------------------------------------------
% Compute target trajectory
tgt_xpos = Tpos(1) + Tvel(1)*time + (1/2)*Tacc(1)*time.^2;
tgt_ypos = Tpos(2) + Tvel(2)*time + (1/2)*Tacc(2)*time.^2;
tgt_zpos = Tpos(3) + Tvel(3)*time + (1/2)*Tacc(3)*time.^2;
tgt_xvel = Tvel(1) + Tacc(1)*time;
tgt_yvel = Tvel(2) + Tacc(2)*time;
tgt_zvel = Tvel(3) + Tacc(3)*time;
tgt_xacc = Tacc(1)*ones(size(time));
tgt_yacc = Tacc(2)*ones(size(time));
tgt_zacc = Tacc(3)*ones(size(time));
tgt_spd  = sqrt(tgt_xvel.^2 + tgt_yvel.^2 + tgt_zvel.^2);

% Compute true bearings and ranges
for kk = 1:length(time)
    xrel            = tgt_xpos(kk) - sen_xpos(kk);
    yrel            = tgt_ypos(kk) - sen_ypos(kk);
    zrel            = tgt_zpos(kk) - sen_zpos(kk);
    tru_btru(kk)    = taninv(xrel,yrel);
    tru_hrng(kk)    = sqrt(xrel*xrel + yrel*yrel);
    tru_srng(kk)    = sqrt(xrel*xrel + yrel*yrel + zrel*zrel);
end

%------------------------------------------------------------------------------------------------------------------------
% Geographic plot
figure;
hold on;
set(gcf,'position',[ -3200 300 1000 700 ]);
plot(sen_xpos(1)*fctr,sen_ypos(1)*fctr,'linestyle','none','marker','o', ...
    'markersize',12,'markeredgecolor','k','markerfacecolor','y');
plot(tgt_xpos(1)*fctr,tgt_ypos(1)*fctr,'linestyle','none','marker','o', ...
    'markersize',12,'markeredgecolor','k','markerfacecolor','y');
plot(sen_xpos*fctr,sen_ypos*fctr,'linestyle','-','linewidth',2,'color','b');
plot(tgt_xpos*fctr,tgt_ypos*fctr,'linestyle','-','linewidth',2,'color','b');
plot_tick_marks_CC_2D(time,sen_xpos*fctr,sen_ypos*fctr,Tics);
plot_tick_marks_CC_2D(time,tgt_xpos*fctr,tgt_ypos*fctr,Tics);
axis equal;
expand_scale(10);
Xarrow = [sen_xpos(end-1) sen_xpos(end)]*fctr;
Yarrow = [sen_ypos(end-1) sen_ypos(end)]*fctr;
draw_arrowhead(Xarrow,Yarrow,'b',200);
Xarrow = [tgt_xpos(end-1) tgt_xpos(end)]*fctr;
Yarrow = [tgt_ypos(end-1) tgt_ypos(end)]*fctr;
draw_arrowhead(Xarrow,Yarrow,'b',200);
xlabel('X Position (Km)','Fontsize',14,'Fontweight','bold');
ylabel('Y Position (Km)','Fontsize',14,'Fontweight','bold');
title ('Geographic Plot','Fontsize',14,'Fontweight','bold');
box on;
grid on;
grid minor;

%------------------------------------------------------------------------------------------------------------------------
% Time range plot
figure;
hold on;
set(gcf,'position',[ -2200 300 1000 700 ]);
plot(time/60,tru_hrng*fctr,'linestyle','-','linewidth',2,'color','k');
plot(time/60,tru_srng*fctr,'linestyle','--','linewidth',2,'color','r');
xlabel('Time (min)','Fontsize',14,'Fontweight','bold');
ylabel('Range (Km)','Fontsize',14,'Fontweight','bold');
title ('Time Range Plot','Fontsize',14,'Fontweight','bold');
box on;
grid on;
grid minor;

%------------------------------------------------------------------------------------------------------------------------
if Test == 1
    % Compute CPA constant velocity case
    Phat = diag([ 100.0^2 100.0^2 1.00^2 1.00^2 ]);
    [CPA_time_CV,CPA_brg_CV,CPA_rng_CV,CPA_time_std_CV,CPA_brg_std_CV,CPA_rng_std_CV, ...
     CPA_xtgt_CV,CPA_ytgt_CV] = ...
        MLE_compute_cpa_2D_PV(Spos,Svel,Tpos,Tvel,Phat,~true);
    % Debug printouts
    fprintf(1,'\n');
    fprintf(1,'  CPA parameters - CV                               \n');
    fprintf(1,'    time  to CPA: %8.3f   std: %8.3f  (min) \n', ...
        CPA_time_CV/60,CPA_time_std_CV/60);
    fprintf(1,'    bearing at CPA: %8.3f   std: %8.3f  (deg) \n', ...
        CPA_brg_CV*rtd,CPA_brg_std_CV*rtd);
    fprintf(1,'    range   at CPA: %8.3f   std: %8.3f  (Km)  \n', ...
        CPA_rng_CV*fctr,CPA_rng_std_CV*fctr);
end

%------------------------------------------------------------------------------------------------------------------------
% Compute CPA accelerating case
Rpos = Tpos - Spos;
Rvel = Tvel - Svel;
Racc = Tacc - Sacc;
if Test == 1
    Phat = diag([ 100.0^2 100.0^2  1.0^2  1.0^2        0      0  ]);
else
   %Phat = diag([ 100.0^2 100.0^2  1.0^2  1.0^2 .001^2 .001^2 ]);
    Phat = diag([ 100.0^2 100.0^2  0.1^2  0.1^2 .001^2 .001^2 ]);
end
[CPA_time_CA,CPA_brg_CA,CPA_rng_CA,CPA_time_std_CA,CPA_brg_std_CA,CPA_rng_std_CA] = ...
    MLE_compute_cpa_2D_PVA(Rpos,Rvel,Racc,Phat);
% Debug printouts
fprintf(1,'\n');
fprintf(1,'  CPA parameters - CA                               \n');
fprintf(1,'    time  to CPA: %8.3f   std: %8.3f  (min) \n', ...
    CPA_time_CA/60, CPA_time_std_CA/60);
fprintf(1,'    bearing at CPA: %8.3f   std: %8.3f  (deg) \n', ...
    CPA_brg_CA*rtd, CPA_brg_std_CA*rtd);
fprintf(1,'    range   at CPA: %8.3f   std: %8.3f  (Km)  \n', ...
    CPA_rng_CA*fctr,CPA_rng_std_CA*fctr);

%------------------------------------------------------------------------------------------------------------------------
% Plot the CPA
figure(1);
if exist('CPA_xtgt_CV','var') && exist('CPA_ytgt_CV','var')
    plot(CPA_xtgt_CV*fctr,CPA_ytgt_CV*fctr,'linestyle','none','marker','o', ...
        'markersize',14,'markeredgecolor','k','markerfacecolor',orange);
    [~,indxS] = find_closest(time,CPA_time_CV);
    draw_cpa_cone_CC(sen_xpos(indxS)*fctr,sen_ypos(indxS)*fctr, ...
                     CPA_rng_CV*fctr,CPA_brg_CV, ...
                     CPA_rng_std_CV*fctr,CPA_brg_std_CV,orange);
    summary1 = {[' CV T_{CPA}: ' num2str(CPA_time_CV/60,    '%6.1f') '     min' ];
                [' \sigma_T:   ' num2str(CPA_time_std_CV/60, '%6.1f') '     '    ];
                [' CV B_{CPA}: ' num2str(CPA_brg_CV*rtd,     '%6.1f') '    ^\circ' ];
                [' \sigma_B:   ' num2str(CPA_brg_std_CV*rtd,  '%6.1f') '    ^\circ' ];
                [' CV R_{CPA}: ' num2str(CPA_rng_CV*fctr,    '%6.3f') '     '    ];
                [' \sigma_R:   ' num2str(CPA_rng_std_CV*fctr, '%6.3f') '     Km'  ]};
    ax   = axis;
    xtxt = ax(1) + .05*(ax(2)-ax(1));
    ytxt = ax(3) + .10*(ax(4)-ax(3));
    text(xtxt,ytxt,summary1,'Fontsize',14,'Fontweight','bold','Fontname', ...
        'Courier New','color',orange);
end
