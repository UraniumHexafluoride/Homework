function [CPA_time,CPA_brg,CPA_rng] = MLE_compute_cpa_acc_2(Rpos,Rvel,Racc)
%------------------------------------------------------------------------------------------------------------------------
%   This function computes 3D CPA parameters given an accelerating sensor
%   and an accelerating contact.
%------------------------------------------------------------------------------------------------------------------------
% Inputs:
%   Rpos - relative  x, y, z   position         (m)             [ 1 x 3 ]
%   Rvel - relative  x, y, z   velocity         (m/s)           [ 1 x 3 ]
%   Racc - relative  x, y, z acceleration       (m/s2)          [ 1 x 3 ]
%------------------------------------------------------------------------------------------------------------------------
% Outputs:
%   CPA_time -      time  at CPA                (sec)
%   CPA_brg  -   bearing  at CPA                (rad)
%   CPA_rng  -  2D range  at CPA                (m)
%------------------------------------------------------------------------------------------------------------------------

% Initialization
CPA_time   = [];
CPA_brg    = [];
CPA_rng    = [];

%------------------------------------------------------------------------------------------------------------------------
% Compute CPA parameters
dnom = Racc*Racc';
if dnom == 0
   % No acceleration
   Tcpa  = -(Rpos*Rvel')/(Rvel*Rvel');
   indxG = [ 1 ];
elseif dnom > 0
   % Non-zero acceleration
   a   = 3*Rvel*Racc'/dnom;
   b   = 2*(Rpos*Racc'+Rvel*Rvel')/dnom;
   c   = 2*Rpos*Rvel'/dnom;
   q   = (a*a-3.0*b)/9.0;
   r   = (2.0*a*a*a-9.0*a*b+27.0*c)/54.0;
   q3  = q*q*q;
   r2  = r*r;
   dis = q3-r2;
   if dis < 0.0
      % one distinct real root
      t1 = -sign((2.0*a*a*a-9.0*a*b+27.0*c)/54.0) * ...
           (((sqrt(((2.0*a*a*a-9.0*a*b+27.0*c)/54.0)^2-((a*a-3.0*b)/9.0)^3) + ...
             abs((2.0*a*a*a-9.0*a*b+27.0*c)/54.0))^(1/3)) + ...
            ((a*a-3.0*b)/9.0)/((sqrt(((2.0*a*a*a-9.0*a*b+27.0*c)/54.0)^2-((a*a-3.0*b)/9.0)^3) + ...
             abs((2.0*a*a*a-9.0*a*b+27.0*c)/54.0))^(1/3))) - a/3;
      Tcpa  = t1;
      indxG = [ 1 ];
   else
      % up to three distinct real roots
      t = 0.0;
      if q3 > 0.0
         ratio = ((2.0*a*a*a-9.0*a*b+27.0*c)/54.0) / sqrt(((a*a-3.0*b)/9.0)^3);
         if abs(ratio) <= 1.0
            t = acos(((2.0*a*a*a-9.0*a*b+27.0*c)/54.0) / sqrt(((a*a-3.0*b)/9.0)^3));
         end
      end
      if q >= 0.0
         t1 = -2.0*sqrt((a*a-3.0*b)/9.0)*cos( acos(((2.0*a*a*a-9.0*a*b+27.0*c)/54.0) / ...
              sqrt(((a*a-3.0*b)/9.0)^3))          /3.0) - a/3.0;
         t2 = -2.0*sqrt((a*a-3.0*b)/9.0)*cos((acos(((2.0*a*a*a-9.0*a*b+27.0*c)/54.0) / ...
              sqrt(((a*a-3.0*b)/9.0)^3)) + 2*pi)/3.0) - a/3.0;
         t3 = -2.0*sqrt((a*a-3.0*b)/9.0)*cos((acos(((2.0*a*a*a-9.0*a*b+27.0*c)/54.0) / ...
              sqrt(((a*a-3.0*b)/9.0)^3)) + 4*pi)/3.0) - a/3.0;
      else
         t1 = -a/3.0;
         t2 = -a/3.0;
         t3 = -a/3.0;
      end
   end
   Tcpa  = sort(unique([ t1 t2 t3 ]'),'ascend');
   indxG = [ 1 : length(Tcpa)];
end

%------------------------------------------------------------------------------------------------------------------------
% Check second derivative to verify minimum range
Ncpa = 0;
if ~isempty(indxG)
   for kk = 1:length(indxG)
       dum_time = Tcpa(indxG(kk));
       dum_Rpos = [ Rpos(1) + Rvel(1)*dum_time + Racc(1)*dum_time.^2/2 ...
                    Rpos(2) + Rvel(2)*dum_time + Racc(2)*dum_time.^2/2 ...
                    Rpos(3) + Rvel(3)*dum_time + Racc(3)*dum_time.^2/2 ];
       dum_Rvel = [ Rvel(1) + Racc(1)*dum_time ...
                    Rvel(2) + Racc(2)*dum_time ...
                    Rvel(3) + Racc(3)*dum_time ];
       dum_Racc = Racc;
       RSddotN  = dum_Rvel*dum_Rvel' + dum_Rpos*dum_Racc';
       if RSddotN > 0
          % Minimum range point
          valid             = true;
          Ncpa              = Ncpa + 1;
          CPA_time(Ncpa)    = dum_time;
          CPA_brg(Ncpa)     = taninv(dum_Rpos(1),dum_Rpos(2));
          CPA_rng(Ncpa)     = norm([dum_Rpos(1:2)]);
       end
   end
end

%------------------------------------------------------------------------------------------------------------------------
% For multiple CPAs, keep the one with minimum future or past time
if Ncpa > 1
   indxN = find(CPA_time < 0);
   if ~isempty(indxN)
      indxK = indxN(end);
   end
   indxP = find(CPA_time > 0);
   if ~isempty(indxP)
      indxK = indxP(1);
   end
   CPA_time = CPA_time(indxK);
   CPA_brg  = CPA_brg(indxK);
   CPA_rng  = CPA_rng(indxK);
end

%------------------------------------------------------------------------------------------------------------------------
return;
