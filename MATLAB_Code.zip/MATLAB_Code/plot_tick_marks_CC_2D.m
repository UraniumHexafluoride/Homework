function [ ] = plot_tick_marks_CC_2D(time,xpos,ypos,Tdel,clrvec,rotation)
%------------------------------------------------------------------------------------------------------------------------
%   This function plots tick marks on the current 2D geographic plot every
%   "Tdel" seconds, if specified.
%------------------------------------------------------------------------------------------------------------------------

if nargin < 5
   clrvec = 'k';
end
if nargin < 6
   rotation = 0;
end

if length(unique(xpos)) == 1 && length(unique(ypos)) == 1
   % stationary target
   return;
end

Tdur = (max(time) - min(time))/60;
if nargin == 3
   if       Tdur <= 10
            Tdel =  2.0*60;
   elseif   Tdur <= 15
            Tdel =  2.5*60;
   elseif   Tdur <= 20
            Tdel =  4.0*60;
   elseif   Tdur <= 30
            Tdel =  5.0*60;
   elseif   Tdur <= 40
            Tdel =  6.0*60;
   elseif   Tdur <= 50
            Tdel =  8.0*60;
   elseif   Tdur <= 60
            Tdel = 10.0*60;
   else
            Tdel = 15.0*60;
   end
end
Tarr = [ time(1) : Tdel : time(end) ];
Tarr = Tarr(1:end);

if ~isempty(Tarr)
   for kk = 1:length(Tarr)
       [~,indxd] = find_closest(time,Tarr(kk));
       if max(time) < 7200
          strng = ['   ' int2str(Tarr(kk)/60)     ]; % minutes
       else
          strng = ['   ' num2str(Tarr(kk)/3600,'%5.1f') ]; % hours
       end
       if abs(time(indxd)-Tarr(kk)) < 1.0
          plot(xpos(indxd),ypos(indxd),'linestyle','none','marker','+', ...
               'markersize',8,'markeredgecolor',clrvec,'markerfacecolor',clrvec);
          text(xpos(indxd),ypos(indxd),strng,'Fontsize',10, ...
               'Fontweight','bold','color',clrvec,'rotation',rotation);
       end
   end
end

%------------------------------------------------------------------------------------------------------------------------
return;
