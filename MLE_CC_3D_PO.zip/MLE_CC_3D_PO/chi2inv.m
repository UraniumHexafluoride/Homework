function x = chi2inv(p, v)
% CHI2INV Inverse of the chi-square cumulative distribution function (CDF).
% Fallback implementation when Statistics and Machine Learning Toolbox is not installed.
% Uses core MATLAB gammaincinv: chi2inv(p, v) = 2 * gammaincinv(p, v/2)

if nargin < 2
    error('chi2inv:TooFewInputs', 'Requires two input arguments.');
end

x = 2 * gammaincinv(p, v / 2);
end
