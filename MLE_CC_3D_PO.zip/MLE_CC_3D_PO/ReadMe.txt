This folder contains the code for an MLE which estimates the 3D position of a stationary contact.
To run the program just type "Test_MLE_CC_3D_PO" which will produce the 2 debug files in this folder.
The algorithm is described in the "MS_MLE_paper.pdf" paper and the scenario is show in the "Pix_scen10a_tru_geo.fig"
file in this folder.  This is a simulation of a Passive Ranging System (PRS) much like that in the Taiwan IDS
program described in the "Generic_ISS_paper.pdf" paper.

The question is this: Can we use the Implicit Function Theorem to speed up the MLE algorithm. If not, what can we do to speed up the Matlab code. The MATLAB code was written to be general vice CPU efficient. I'm sure there are a number of ways to speed up the processing.
