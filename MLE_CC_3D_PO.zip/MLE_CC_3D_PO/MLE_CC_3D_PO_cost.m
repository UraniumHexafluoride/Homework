function [cost,ChiSqrN,Nmsr,Resid] = MLE_CC_3D_PO_cost(Xhat,Meas)
%------------------------------------------------------------------
% This function computes the Cartesian Coordinate cost function given
% FM time delay and MA time delay measurements.
% The unweighted residuals are also returned.
% The state vector is assumed to be of the form [ xpos ypos zpos ]t.
% Note: The "cost" is weighted while the individual residual vectors are
% not weighted.
%------------------------------------------------------------------
global MLE_parms;

% Initialization
Xtgt    = Xhat(1);
Ytgt    = Xhat(2);
Ztgt    = Xhat(3);
Zbot    = MLE_parms.Zbot;
Nstates = length(Xhat);
Nrpt    = length(Meas);
cost    = 0.0;
Nmsr    = 0;

% Compute cost function
for mm = 1:Nrpt
    kk = Nrpt - mm + 1;
    Xrel = Xtgt - Meas(kk).Xsen;
    Yrel = Ytgt - Meas(kk).Ysen;
    Zrel = Ztgt - Meas(kk).Zsen;
    if isfield(Meas(kk),'TFM') && ~isempty(Meas(kk).TFM) && ...
       isfield(Meas(kk),'TMA') && ~isempty(Meas(kk).TMA)
        [tau_fm,tau_ma,~,~,~,~] = ...
            MLE_compute_PRS_time_delays(Meas(kk).Xown,Meas(kk).Yown,Meas(kk).Zown,Meas(kk).Senhdg, ...
            Xtgt,Ytgt,Ztgt,Meas(kk).Nrev,Zbot);
        % fwd mid time delay measurement
        Nmsr = Nmsr + 1;
        Tres = Meas(kk).TFM - tau_fm;
        cost = cost + (Tres/Meas(kk).TFMsig)^2;
        Resid(Nmsr).Time = Meas(kk).Time;
        Resid(Nmsr).TFMres = Tres;
        Resid(Nmsr).TFMsig = Meas(kk).TFMsig;
        % mid aft time delay measurement
        Nmsr = Nmsr + 1;
        Tres = Meas(kk).TMA - tau_ma;
        cost = cost + (Tres/Meas(kk).TMAsig)^2;
        Resid(Nmsr).Time = Meas(kk).Time;
        Resid(Nmsr).TMAres = Tres;
        Resid(Nmsr).TMAsig = Meas(kk).TMAsig;
    end
end

% Implement range constraint
if MLE_parms.Rng_con_flg
    Nmsr = Nmsr + 1;
    Rngpre = sqrt(Xrel*Xrel + Yrel*Yrel + Zrel*Zrel);
    Rngres = MLE_parms.Rng_con_val - Rngpre;
    cost = cost + (Rngres/MLE_parms.Rng_con_sig)^2;
end

% Compute Chi squared statistic
ChiSqrN = cost/(max(1,Nmsr-Nstates));

return;
