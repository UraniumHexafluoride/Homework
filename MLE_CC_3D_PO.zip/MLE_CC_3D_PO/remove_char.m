function [strng] = remove_char(strng)
%------------------------------------------------------------------
% This function removes characters from a string.
%------------------------------------------------------------------
% Remove underscores, dashes, slashes
strng(strng == '_') = ' ';
strng(strng == '-') = ' ';
strng(strng == '\') = ' ';

return;
