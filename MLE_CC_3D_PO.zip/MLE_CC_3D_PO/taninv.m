function [ a ] = taninv(x,y)
%------------------------------------------------------------------
% This function is an inverse tangent function which returns an angle
% in [0,2pi).
%------------------------------------------------------------------

a = atan2(x,y);
indxl = find(a < 0);
if ~isempty(indxl)
    a(indxl) = a(indxl) + 2*pi;
end

return;
