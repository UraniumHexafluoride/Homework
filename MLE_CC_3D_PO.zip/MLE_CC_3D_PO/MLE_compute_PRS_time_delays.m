function [tau_fm,tau_ma,PSind,PRS_Fpos,PRS_Mpos,PRS_Apos] = ...
    MLE_compute_PRS_time_delays(xown,yown,zown,shdg, ...
    xtgt,ytgt,ztgt,Nrev,Zbot)
%------------------------------------------------------------------
% This function computes the PRS fwd-mid and mid-aft time delays.
% The panel acoustic centers can be collinear or non-collinear.
% Units are assued to be in meters.
%
% Inputs:
%   xown     - ownship x position           (m)
%   yown     - ownship y position           (m)
%   zown     - ownship z position           (m)
%   shdg     - sensor heading               (r)
%   xtgt     - target x position            (m)
%   ytgt     - target y position            (m)
%   ztgt     - target z position            (m)
%   Nrev     - number of ray reversals      (0=DP, 1=BB)
%   Zbot     - ocean bottom depth           (m)
% Outputs:
%   tau_fm   - fwd-mid time delay           (sec)
%   tau_ma   - mid-aft time delay           (sec)
%   PSind    - port/starboard indicator     "port" or "stbd"
%   PRS_Fpos - PRS forward x,y,z position   (m)
%   PRS_Mpos - PRS mid x,y,z position       (m)
%   PRS_Apos - PRS aft x,y,z position       (m)
%------------------------------------------------------------------
global MLE_parms;

% Initialization
define_constants;
Cavg  = MLE_parms.Cavg;
Model = MLE_parms.PRS_model;
units = MLE_parms.units;

% Compute relative target bearing wrt sensor to determine port/stbd
xrel = xtgt - xown;
yrel = ytgt - yown;
brel = addrad(taninv(xrel,yrel),-shdg);
if brel > pi
    PSind = +1;
else
    PSind = -1;
end

% Compute panel positions
[PRS_Fpos,PRS_Mpos,PRS_Apos] = ...
    MLE_define_PRS_panel_positions(Model,xown,yown,zown,shdg);

% Calculate time delays using true distances to the panels
xrelF = xtgt - PRS_Fpos(1);
yrelF = ytgt - PRS_Fpos(2);
xrelM = xtgt - PRS_Mpos(1);
yrelM = ytgt - PRS_Mpos(2);
xrelA = xtgt - PRS_Apos(1);
yrelA = ytgt - PRS_Apos(2);

[zrelF,~,~,~] = zimage_parms(Nrev,Zbot,PRS_Fpos(3),ztgt);
[zrelM,~,~,~] = zimage_parms(Nrev,Zbot,PRS_Mpos(3),ztgt);
[zrelA,~,~,~] = zimage_parms(Nrev,Zbot,PRS_Apos(3),ztgt);

rngF = sqrt(xrelF*xrelF + yrelF*yrelF);
rngM = sqrt(xrelM*xrelM + yrelM*yrelM);
rngA = sqrt(xrelA*xrelA + yrelA*yrelA);
srgF = sqrt(xrelF*xrelF + yrelF*yrelF + zrelF*zrelF);
srgM = sqrt(xrelM*xrelM + yrelM*yrelM + zrelM*zrelM);
srgA = sqrt(xrelA*xrelA + yrelA*yrelA + zrelA*zrelA);

brgF = taninv(xrelF,yrelF);
brgM = taninv(xrelM,yrelM);
brgA = taninv(xrelA,yrelA);

tvlF = srgF/Cavg;
tvlM = srgM/Cavg;
tvlA = srgA/Cavg;

tau_fm = tvlM - tvlF;
tau_ma = tvlA - tvlM;

if 0
    L1 = norm(PRS_Fpos - PRS_Mpos);
    L2 = norm(PRS_Mpos - PRS_Apos);
    fprintf(1,' Nrev     %14.6f \n',Nrev);
    fprintf(1,' xown     %14.6f \n',xown);
    fprintf(1,' yown     %14.6f \n',yown);
    fprintf(1,' zown     %14.6f \n',zown);
    fprintf(1,' shdg     %14.6f \n',shdg*180/pi);
    fprintf(1,' xtgt     %14.6f \n',xtgt);
    fprintf(1,' ytgt     %14.6f \n',ytgt);
    fprintf(1,' ztgt     %14.6f \n',ztgt);
    fprintf(1,' PSind    %10d   \n',PSind);
    fprintf(1,' PRS_xfwd %14.6f \n',PRS_Fpos(1));
    fprintf(1,' PRS_yfwd %14.6f \n',PRS_Fpos(2));
    fprintf(1,' PRS_zfwd %14.6f \n',PRS_Fpos(3));
    fprintf(1,' PRS_xmid %14.6f \n',PRS_Mpos(1));
    fprintf(1,' PRS_ymid %14.6f \n',PRS_Mpos(2));
    fprintf(1,' PRS_zmid %14.6f \n',PRS_Mpos(3));
    fprintf(1,' PRS_xaft %14.6f \n',PRS_Apos(1));
    fprintf(1,' PRS_yaft %14.6f \n',PRS_Apos(2));
    fprintf(1,' PRS_zaft %14.6f \n',PRS_Apos(3));
    fprintf(1,' rng_fwd  %14.6f \n',rngF);
    fprintf(1,' rng_mid  %14.6f \n',rngM);
    fprintf(1,' rng_aft  %14.6f \n',rngA);
    fprintf(1,' srg_fwd  %14.6f \n',srgF);
    fprintf(1,' srg_mid  %14.6f \n',srgM);
    fprintf(1,' srg_aft  %14.6f \n',srgA);
    fprintf(1,' zrel_fwd %14.6f \n',zrelF);
    fprintf(1,' zrel_mid %14.6f \n',zrelM);
    fprintf(1,' zrel_aft %14.6f \n',zrelA);
    fprintf(1,' brg_fwd  %14.6f \n',brgF*rtd);
    fprintf(1,' brg_mid  %14.6f \n',brgM*rtd);
    fprintf(1,' brg_aft  %14.6f \n',brgA*rtd);
    fprintf(1,' tvl_fwd  %14.6f \n',tvlF);
    fprintf(1,' tvl_mid  %14.6f \n',tvlM);
    fprintf(1,' tvl_aft  %14.6f \n',tvlA);
    fprintf(1,' tau_fm   %14.6f \n',tau_fm*1.e6);
    fprintf(1,' tau_ma   %14.6f \n',tau_ma*1.e6);
    fprintf(1,' L1       %14.6f \n',L1);
    fprintf(1,' L2       %14.6f \n',L2);
    fprintf(1,' ================================\n');
end

return;
