function [L1,L2,coll_flag] = plot_PRS_panel_positions(Model,PRS_Fpos,PRS_Mpos,PRS_Apos)
% PLOT_PRS_PANEL_POSITIONS Plots the acoustic center positions and computes baselines.
L1 = norm(PRS_Fpos - PRS_Mpos);
L2 = norm(PRS_Apos - PRS_Mpos);
coll_flag = (Model == 1 || Model == 2 || Model == 6);

figure('Name','PRS Panel Positions');
plot3([PRS_Fpos(1) PRS_Mpos(1) PRS_Apos(1)], ...
      [PRS_Fpos(2) PRS_Mpos(2) PRS_Apos(2)], ...
      [PRS_Fpos(3) PRS_Mpos(3) PRS_Apos(3)], 'o-');
grid on;
xlabel('X (m)'); ylabel('Y (m)'); zlabel('Z (m)');
title(sprintf('PRS Panels: Model %d, L1=%.3f m, L2=%.3f m', Model, L1, L2));
return;
