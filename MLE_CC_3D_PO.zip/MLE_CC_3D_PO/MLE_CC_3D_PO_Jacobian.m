function [Jmtx,Yres] = MLE_CC_3D_PO_Jacobian(Xhat,Meas)
%------------------------------------------------------------------
% This function computes the Cartesian coordinate Jacobian matrix and
% residual vector given FM time delay and MA time delay measurements.
% The state vector is assumed to be of the form [ xpos ypos zpos ]t.
%------------------------------------------------------------------
global MLE_parms;

% Compute Jacobian matrix dh(X) / d(X)
Zbot = MLE_parms.Zbot;
Cavg = MLE_parms.Cavg;
Xtgt = Xhat(1);
Ytgt = Xhat(2);
Ztgt = Xhat(3);
Nstates = length(Xhat);
[~,~,~,Ntfm] = find_meas_indx(Meas,'tfm');
[~,~,~,Ntma] = find_meas_indx(Meas,'tma');
Nrpt = length(Meas);
Nmeas = Ntfm + Ntma;
if MLE_parms.Rng_con_flg
    Nmeas = Nmeas + 1;
end
Jmtx = zeros(Nmeas,Nstates);
Yres = zeros(Nmeas,1);
row = 0;

for mm = 1:Nrpt
    kk = Nrpt - mm + 1;
    Xrel = Xtgt - Meas(kk).Xsen;
    Yrel = Ytgt - Meas(kk).Ysen;
    Zrel = Ztgt - Meas(kk).Zsen;
    if isfield(Meas(kk),'TFM') && ~isempty(Meas(kk).TFM) && ...
       isfield(Meas(kk),'TMA') && ~isempty(Meas(kk).TMA)
        shdg = Meas(kk).Senhdg;
        [tau_fm,tau_ma,~,PRS_Fpos,PRS_Mpos,PRS_Apos] = ...
            MLE_compute_PRS_time_delays(Meas(kk).Xown,Meas(kk).Yown,Meas(kk).Zown,shdg, ...
            Xtgt,Ytgt,Ztgt,Meas(kk).Nrev,Zbot);
        
        XrelF = Xtgt - PRS_Fpos(1);
        YrelF = Ytgt - PRS_Fpos(2);
        [ZrelF,~,~,~] = zimage_parms(Meas(kk).Nrev,Zbot,PRS_Fpos(3),Ztgt);
        Rpref = max(1.0,sqrt(XrelF*XrelF + YrelF*YrelF + ZrelF*ZrelF));
        drfdxm = XrelF/Rpref;
        drfdym = YrelF/Rpref;
        drfdzm = ZrelF/Rpref;
        
        XrelM = Xtgt - PRS_Mpos(1);
        YrelM = Ytgt - PRS_Mpos(2);
        [ZrelM,~,~,~] = zimage_parms(Meas(kk).Nrev,Zbot,PRS_Mpos(3),Ztgt);
        Rprem = max(1.0,sqrt(XrelM*XrelM + YrelM*YrelM + ZrelM*ZrelM));
        drmdxm = XrelM/Rprem;
        drmdym = YrelM/Rprem;
        drmdzm = ZrelM/Rprem;
        
        XrelA = Xtgt - PRS_Apos(1);
        YrelA = Ytgt - PRS_Apos(2);
        [ZrelA,~,~,~] = zimage_parms(Meas(kk).Nrev,Zbot,PRS_Apos(3),Ztgt);
        Rprea = max(1.0,sqrt(XrelA*XrelA + YrelA*YrelA + ZrelA*ZrelA));
        dradxm = XrelA/Rprea;
        dradym = YrelA/Rprea;
        dradzm = ZrelA/Rprea;
        
        % fwd mid time delay measurement
        row = row + 1;
        TFMres = Meas(kk).TFM - tau_fm;
        % calculate dTFM/dx
        dtdxm = (drmdxm - drfdxm)/Cavg;
        dtdym = (drmdym - drfdym)/Cavg;
        dtdzm = (drmdzm - drfdzm)/Cavg;
        denom = Meas(kk).TFMsig;
        Jmtx(row,1) = dtdxm / denom;
        Jmtx(row,2) = dtdym / denom;
        Jmtx(row,3) = dtdzm / denom;
        Yres(row,1) = TFMres / denom;
        
        % mid aft time delay measurement
        row = row + 1;
        TMAres = Meas(kk).TMA - tau_ma;
        % calculate dTMA/dx
        dtdxm = (dradxm - drmdxm)/Cavg;
        dtdym = (dradym - drmdym)/Cavg;
        dtdzm = (dradzm - drmdzm)/Cavg;
        denom = Meas(kk).TMAsig;
        Jmtx(row,1) = dtdxm / denom;
        Jmtx(row,2) = dtdym / denom;
        Jmtx(row,3) = dtdzm / denom;
        Yres(row,1) = TMAres / denom;
    end
end

% Implement range constraint
if MLE_parms.Rng_con_flg
    row = row + 1;
    Rpre = sqrt(Xrel*Xrel + Yrel*Yrel + Zrel*Zrel);
    Rres = MLE_parms.Rng_con_val - Rpre;
    % calculate dRng/dx
    drdxm = Xrel/Rpre;
    drdym = Yrel/Rpre;
    drdzm = Zrel/Rpre;
    denom = MLE_parms.Rng_con_sig;
    Jmtx(row,1) = drdxm / denom;
    Jmtx(row,2) = drdym / denom;
    Jmtx(row,3) = drdzm / denom;
    Yres(row,1) = Rres / denom;
end

return;
