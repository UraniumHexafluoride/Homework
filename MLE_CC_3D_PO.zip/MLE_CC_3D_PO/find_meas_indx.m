function [indx,indx_min,indx_max,N] = find_meas_indx(Meas,Type,Array)
%------------------------------------------------------------------
% This function finds the indicies into the measurement structure "Meas"
% associated with the measurement type "Type". If "Array" is provided,
% this function will find the indicies associated with that array only.
%------------------------------------------------------------------

indx = [];
for kk = 1:length(Meas)
    if strcmp(Type,'ang') || strcmp(Type,'Ang')
        if (isfield(Meas(kk),'Brg') && ~isempty(Meas(kk).Brg)) || ...
           (isfield(Meas(kk),'Con') && ~isempty(Meas(kk).Con))
            if nargin == 2
                indx = [ indx kk ];
            elseif nargin == 3 && Meas(kk).Array == Array
                indx = [ indx kk ];
            end
        end
    elseif strcmp(Type,'brg') || strcmp(Type,'Brg')
        if isfield(Meas(kk),'Brg') && ~isempty(Meas(kk).Brg)
            if nargin == 2
                indx = [ indx kk ];
            elseif nargin == 3 && Meas(kk).Array == Array
                indx = [ indx kk ];
            end
        end
    elseif strcmp(Type,'con') || strcmp(Type,'Con')
        if isfield(Meas(kk),'Con') && ~isempty(Meas(kk).Con)
            if nargin == 2
                indx = [ indx kk ];
            elseif nargin == 3 && Meas(kk).Array == Array
                indx = [ indx kk ];
            end
        end
    elseif strcmp(Type,'dea') || strcmp(Type,'Dea')
        if isfield(Meas(kk),'Dea') && ~isempty(Meas(kk).Dea)
            if nargin == 2
                indx = [ indx kk ];
            elseif nargin == 3 && Meas(kk).Array == Array
                indx = [ indx kk ];
            end
        end
    elseif strcmp(Type,'rng') || strcmp(Type,'Rng')
        if isfield(Meas(kk),'Rng') && ~isempty(Meas(kk).Rng)
            if nargin == 2
                indx = [ indx kk ];
            elseif nargin == 3 && Meas(kk).Array == Array
                indx = [ indx kk ];
            end
        end
    elseif strcmp(Type,'srg') || strcmp(Type,'Srg')
        if isfield(Meas(kk),'Srg') && ~isempty(Meas(kk).Srg)
            if nargin == 2
                indx = [ indx kk ];
            elseif nargin == 3 && Meas(kk).Array == Array
                indx = [ indx kk ];
            end
        end
    elseif strcmp(Type,'isr') || strcmp(Type,'Isr')
        if isfield(Meas(kk),'Isr') && ~isempty(Meas(kk).Isr)
            if nargin == 2
                indx = [ indx kk ];
            elseif nargin == 3 && Meas(kk).Array == Array
                indx = [ indx kk ];
            end
        end
    elseif strcmp(Type,'TFM') || strcmp(Type,'tfm')
        if isfield(Meas(kk),'TFM') && ~isempty(Meas(kk).TFM)
            if nargin == 2
                indx = [ indx kk ];
            elseif nargin == 3 && Meas(kk).Array == Array
                indx = [ indx kk ];
            end
        end
    elseif strcmp(Type,'TMA') || strcmp(Type,'tma')
        if isfield(Meas(kk),'TMA') && ~isempty(Meas(kk).TMA)
            if nargin == 2
                indx = [ indx kk ];
            elseif nargin == 3 && Meas(kk).Array == Array
                indx = [ indx kk ];
            end
        end
    elseif strcmp(Type,'frq1') || strcmp(Type,'Frq1')
        if isfield(Meas(kk),'Frq1') && ~isempty(Meas(kk).Frq1)
            if nargin == 2
                indx = [ indx kk ];
            elseif nargin == 3 && Meas(kk).Array == Array
                indx = [ indx kk ];
            end
        end
    elseif strcmp(Type,'frq2') || strcmp(Type,'Frq2')
        if isfield(Meas(kk),'Frq2') && ~isempty(Meas(kk).Frq2)
            if nargin == 2
                indx = [ indx kk ];
            elseif nargin == 3 && Meas(kk).Array == Array
                indx = [ indx kk ];
            end
        end
    elseif strcmp(Type,'frq3') || strcmp(Type,'Frq3')
        if isfield(Meas(kk),'Frq3') && ~isempty(Meas(kk).Frq3)
            if nargin == 2
                indx = [ indx kk ];
            elseif nargin == 3 && Meas(kk).Array == Array
                indx = [ indx kk ];
            end
        end
    end
end

indx_min = min(indx);
indx_max = max(indx);
N = length(indx);

return;
