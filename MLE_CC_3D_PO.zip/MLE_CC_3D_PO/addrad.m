function [angle] = addrad(angle1,angle2)
%------------------------------------------------------------------
% This function adds angles (radians) where the result is in [0,2pi).
%------------------------------------------------------------------

angle = angle1 + angle2;

indxl = find(angle < 0 );
indxh = find(angle > 2*pi);

if ~isempty(indxl)
    angle(indxl) = angle(indxl) + 2*pi;
end
if ~isempty(indxh)
    angle(indxh) = angle(indxh) - 2*pi;
end

return;
