function [rng,brg,dpt,rsig,bsig,zsig] = ...
    MLE_CC_3D_PO_soln(xref,yref,Xhat,Phat,Prb)
%------------------------------------------------------------------
% This function computes target range, bearing and depth along with the
% appropriate standard deviations with respect to a reference point.
%------------------------------------------------------------------
global MLE_parms;

%------------------------------------------------------------------
% Compute range, bearing and depth
define_constants;
xrel = Xhat(1) - xref;
yrel = Xhat(2) - yref;
rng = sqrt(xrel*xrel + yrel*yrel);
brg = taninv(xrel,yrel);
dpt = Xhat(3);

%------------------------------------------------------------------
% Compute range, bearing and depth standard deviations
rsig = Phat(1,1)*xrel * xrel + 2.0*Phat(1,2)*xrel * yrel ...
     + Phat(2,2)*yrel * yrel;
rsig = sqrt(rsig / rng^2);
bsig = Phat(1,1)*yrel * yrel - 2.0*Phat(1,2)*xrel * yrel ...
     + Phat(2,2)*xrel * xrel;
bsig = sqrt(bsig / rng^4);
zsig = sqrt(Phat(3,3));

%------------------------------------------------------------------
% Limit standard deviations
if rsig > 10000.0
    rsig = 10000.0;
elseif rsig < 1.0
    rsig = 1.0;
end
if bsig > 90.0*dtr
    bsig = 90.0*dtr;
elseif bsig < .01*dtr
    bsig = .01*dtr;
end
if zsig > 10000.0
    zsig = 10000.0;
elseif zsig < 1.0
    zsig = 1.0;
end

%------------------------------------------------------------------
% Compute the area of the 2D localization ellipse
P11 = Phat(1,1);
P22 = Phat(2,2);
P12 = Phat(1,2);
xlam = sqrt((P22-P11)^2 + 4*P12^2);
smajor = (P11 + P22 + xlam)/2;
sminor = (P11 + P22 - xlam)/2;
if P12 == 0.0 && smajor == P11
    orien = pi/2;
else
    orien = atan2(P12,smajor-P11);
end
scale = sqrt(-2*log(1-Prb));
smajor = sqrt(smajor)*scale;
sminor = sqrt(sminor)*scale;
if smajor > 10000.0
    smajor = 10000.0;
elseif smajor < 1.0
    smajor = 1.0;
end
if sminor > 10000.0
    sminor = 10000.0;
elseif sminor < 1.0
    sminor = 1.0;
end
area = pi*smajor*sminor;

%------------------------------------------------------------------
% Debug printouts
if MLE_parms.dbug_flag
    fid2 = MLE_parms.fid2;
    fprintf(fid2, '                                       \n');
    fprintf(fid2, '                                       \n');
    fprintf(fid2, ' Solution parameters wrt ownship       \n');
    fprintf(fid2, '   Tgt rng %9.2f  std %9.2f (m)        \n', ...
        rng,rsig);
    fprintf(fid2, '   Tgt brg %9.2f  std %9.2f (deg)      \n', ...
        brg*rtd,bsig*rtd);
    fprintf(fid2, '   Tgt dpt %9.2f  std %9.2f (m)        \n', ...
        dpt,zsig);
    fprintf(fid2, '                                       \n');
    fprintf(fid2, '                                       \n');
    fprintf(fid2, ' Ellipse parameters - 2D               \n');
    fprintf(fid2, '   Scale factor     %7.3f              \n',scale);
    fprintf(fid2, '   Semi major       %7.1f (m)          \n',smajor);
    fprintf(fid2, '   Semi minor       %7.1f (m)          \n',sminor);
    fprintf(fid2, '   Orientation      %7.2f (deg)        \n',orien*rtd);
    fprintf(fid2, '   Ellipse area     %7.1f (m^2)        \n',area);
end

return;
