% Test_MLE_CC_3D_PO
%--------------------------------------------------------------------------
%
% This program computes the range, bearing and depth of a contact given
% time delay measurements only via the Cartesian coordinate (CC) 3D Position
% Only (PO) MLE algorithm.
% Note: For some direct path cases, this algorithm can not resolve if
%       the contact is above or below you and will converge to one of
%       two possible solutions.
%--------------------------------------------------------------------------
close all;
fclose all;
clearvars;
global MLE_parms;

%--------------------------------------------------------------------------
% Add path(s)
restoredefaultpath;
% cd 'C:\Users\mcphil1k\Documents\Richard_Charette\MS_MLE_3D_PO_tau'
addpath(pwd);

%--------------------------------------------------------------------------
% Initialization
define_constants;

%--------------------------------------------------------------------------
% Define MLE parameters
MLE_parms.Algorithm     = 'MLE_CC_2D_PO';
MLE_parms.units         = 'm';               % units
MLE_parms.Scenario      = 2;                 % scenario number
MLE_parms.Tmin          = 0.0*60;            % minimum time            (sec)
MLE_parms.Tmax          = 15.0*60;           % maximum time            (sec)
%MLE_parms.Tmax         = 30.0*60;           % maximum time            (sec)
MLE_parms.PRS_model     = 6;                 % PRS array model         (int)
MLE_parms.max_iter      = 25;                % maximum number of iterations (int)
MLE_parms.max_srch      = 21;                % maximum number of line search steps (int)
MLE_parms.Rng_max       = 10000.0;           % maximum contact range   (m)
MLE_parms.Rng_con_flg   = true;              % range constraint flag   (true/false)
MLE_parms.Rng_con_val   = 5000.0;            % range constraint value  (m)
MLE_parms.Rng_con_sig   = 5000.0;            % range constraint standard deviation (m)
MLE_parms.Prob          = 0.90;              % ellipse probability of containment (0-1)
MLE_parms.alpha         = 0.01;              % probability of false position (0-1)
MLE_parms.dbug_flag     = true;              % debug flag              (true/false)
MLE_parms.fid1 = fopen(['Debug_MLE_CC_3D_PO_1_scen_' int2str(MLE_parms.Scenario) '.txt'],'w');
MLE_parms.fid2 = fopen(['Debug_MLE_CC_3D_PO_2_scen_' int2str(MLE_parms.Scenario) '.txt'],'w');

%--------------------------------------------------------------------------
% Load the scenario file
file_name = 'Meas_CASPRSTWD_10a_6_DP.mat';
if exist([file_name],'file')
   load([file_name]);
   fprintf(1,' Meas file has been loaded \n');
else
   fprintf(1,' Meas file does not exist \n');
   return;
end
indxM = find([Meas.Time] >= MLE_parms.Tmin & [Meas.Time] <= MLE_parms.Tmax );
Meas = Meas(indxM);
indxT = find([Truth.Time] >= MLE_parms.Tmin & [Truth.Time] <= MLE_parms.Tmax );
Truth = Truth(indxT);
MLE_parms.Cavg = Cavg;                      % sound speed             (m/s)
MLE_parms.Zbot = Zbot;                      % ocean bottom depth      (m)
MLE_parms.Nrev = Meas(1).Nrev;              % number of ray reversals (int)

%--------------------------------------------------------------------------
% Run the algorithm
indxT = find([Truth.Time] == Meas(end).Time);
Xhat = [ Truth(indxT).Xtgt Truth(indxT).Ytgt Truth(indxT).Ztgt ]';
%Xerr = [    0.0     0.0    0.0 ]';
%Xerr = [ +1000.0     0.0    0.0 ]';
%Xerr = [    0.0 -1000.0    0.0 ]';
%Xerr = [    0.0     0.0  -50.0 ]';
%Xerr = [ +1000.0 -1000.0    0.0 ]';
Xerr = [ +1000.0 -1000.0  -50.0 ]';
Xhat = Xhat + Xerr;
[Xhat,Phat,cst_min,chi_sqrN,Nmsr,conv_flag,vldt_flag] = ...
    MLE_CC_3D_PO_algorithm(Meas,Xhat);

%--------------------------------------------------------------------------
fclose all;
return;
