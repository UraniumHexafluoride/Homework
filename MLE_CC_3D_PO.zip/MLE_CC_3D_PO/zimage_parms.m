function [rzhat,n1,n2,n3] = zimage_parms(nrev,zbot,zsen,ztgt)
%------------------------------------------------------------------
% This function computes the image plane depth given a number of ray
% reversals, bottom depth, sensor depth and target depth.
%------------------------------------------------------------------

m1 = mod(nrev,2);
if m1 == 0
    % even number of ray reversals
    if nrev >= 0
        % signal received below horizontal
        n1 = nrev;
        n2 = -1;
        n3 = +1;
    else
        % signal received above horizontal
        n1 = +nrev;
        n2 = -1;
        n3 = +1;
    end
else
    % odd number of ray reversals
    if nrev > 0
        % signal received below horizontal
        n1 = nrev+1;
        n2 = -1;
        n3 = -1;
    else
        % signal received above horizontal
        n1 = nrev+1;
        n2 = -1;
        n3 = -1;
    end
end

rzhat = n1*zbot+n2*zsen+n3*ztgt;

return;
