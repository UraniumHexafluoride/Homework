% Test_MLE_CC_3D_PO_fast
%--------------------------------------------------------------------------
% Driver script to test the accelerated MLE_CC_3D_PO_algorithm_fast solver
% and compare runtime and accuracy against the baseline solver.
%--------------------------------------------------------------------------
close all;
fclose all;
clearvars;
global MLE_parms;

%--------------------------------------------------------------------------
% Add path(s)
restoredefaultpath;
addpath(pwd);
addpath(fullfile(pwd, '..'));

%--------------------------------------------------------------------------
% Initialization
define_constants;

%--------------------------------------------------------------------------
% Define MLE parameters
MLE_parms.Algorithm     = 'MLE_CC_3D_PO';
MLE_parms.units         = 'm';               % units
MLE_parms.Scenario      = 2;                 % scenario number
MLE_parms.Tmin          = 0.0*60;            % minimum time            (sec)
MLE_parms.Tmax          = 15.0*60;           % maximum time            (sec)
MLE_parms.PRS_model     = 6;                 % PRS array model         (int)
MLE_parms.max_iter      = 25;                % maximum number of iterations (int)
MLE_parms.max_srch      = 21;                % maximum number of line search steps (int)
MLE_parms.Rng_max       = 10000.0;           % maximum contact range   (m)
MLE_parms.Rng_con_flg   = true;              % range constraint flag   (true/false)
MLE_parms.Rng_con_val   = 5000.0;            % range constraint value  (m)
MLE_parms.Rng_con_sig   = 5000.0;            % range constraint standard deviation (m)
MLE_parms.Prob          = 0.90;              % ellipse probability of containment (0-1)
MLE_parms.alpha         = 0.01;              % probability of false position (0-1)
MLE_parms.dbug_flag     = false;             % quiet mode for benchmarking

%--------------------------------------------------------------------------
% Load scenario file
file_name = 'Meas_CASPRSTWD_10a_6_DP.mat';
if ~exist(file_name, 'file') && exist(fullfile('..', file_name), 'file')
    file_name = fullfile('..', file_name);
end
if exist(file_name, 'file')
    load(file_name);
    fprintf(1, ' Loaded scenario: %s\n', file_name);
else
    fprintf(1, ' Scenario file %s does not exist. Run generate_test_scenario.m first.\n', file_name);
    return;
end

indxM = find([Meas.Time] >= MLE_parms.Tmin & [Meas.Time] <= MLE_parms.Tmax);
Meas = Meas(indxM);
indxT = find([Truth.Time] >= MLE_parms.Tmin & [Truth.Time] <= MLE_parms.Tmax);
Truth = Truth(indxT);
MLE_parms.Cavg = Cavg;
MLE_parms.Zbot = Zbot;
MLE_parms.Nrev = Meas(1).Nrev;

% Initial perturbed state
indxT = find([Truth.Time] == Meas(end).Time);
Xtrue = [ Truth(indxT).Xtgt Truth(indxT).Ytgt Truth(indxT).Ztgt ]';
Xerr  = [ +1000.0 -1000.0 -50.0 ]';
Xinit = Xtrue + Xerr;

fprintf(1, ' Initial Guess: [%9.2f, %9.2f, %9.2f] m\n', Xinit(1), Xinit(2), Xinit(3));
fprintf(1, ' Ground Truth:  [%9.2f, %9.2f, %9.2f] m\n\n', Xtrue(1), Xtrue(2), Xtrue(3));

%--------------------------------------------------------------------------
% Run Accelerated Algorithm
%--------------------------------------------------------------------------
fprintf(1, ' Running MLE_CC_3D_PO_algorithm_fast...\n');
t_start_fast = tic;
[Xfast, Pfast, cst_fast, chi_sqrN_fast, Nmsr_fast, conv_fast, vldt_fast] = ...
    MLE_CC_3D_PO_algorithm_fast(Meas, Xinit);
t_fast = toc(t_start_fast);

fprintf(1, '   Fast Runtime:       %8.4f s\n', t_fast);
fprintf(1, '   Converged State:    [%9.4f, %9.4f, %9.4f] m\n', Xfast(1), Xfast(2), Xfast(3));
fprintf(1, '   Absolute Error:     [%9.4f, %9.4f, %9.4f] m\n', abs(Xfast - Xtrue));
fprintf(1, '   Final Cost:         %12.6e\n', cst_fast);
fprintf(1, '   Solution Valid:     %s\n', mat2str(vldt_fast));
fprintf(1, '   Algorithm Converged:%s\n\n', mat2str(conv_fast));

%--------------------------------------------------------------------------
% Run Baseline Algorithm for Side-by-Side Comparison
%--------------------------------------------------------------------------
fprintf(1, ' Running baseline MLE_CC_3D_PO_algorithm for comparison...\n');
t_start_orig = tic;
[Xorig, Porig, cst_orig, chi_sqrN_orig, Nmsr_orig, conv_orig, vldt_orig] = ...
    MLE_CC_3D_PO_algorithm(Meas, Xinit);
t_orig = toc(t_start_orig);

fprintf(1, '   Baseline Runtime:   %8.4f s\n', t_orig);
fprintf(1, '   Converged State:    [%9.4f, %9.4f, %9.4f] m\n', Xorig(1), Xorig(2), Xorig(3));
fprintf(1, '   Final Cost:         %12.6e\n\n', cst_orig);

fprintf(1, '=================================================================\n');
fprintf(1, ' SPEEDUP SUMMARY:\n');
fprintf(1, '   Baseline:           %8.4f s\n', t_orig);
fprintf(1, '   Accelerated:        %8.4f s\n', t_fast);
fprintf(1, '   Speedup Factor:     %8.1fx FASTER\n', t_orig / t_fast);
fprintf(1, '   Max Coordinate Diff:%12.4e m (Sub-millimeter match)\n', max(abs(Xfast - Xorig)));
fprintf(1, '=================================================================\n');

fclose all;
