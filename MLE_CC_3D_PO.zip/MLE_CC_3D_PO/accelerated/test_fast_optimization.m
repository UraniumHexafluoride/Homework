% test_fast_optimization.m
% Implements and benchmarks the vectorized, precomputed fast MLE algorithm.

clearvars;
close all;

load('Meas_CASPRSTWD_10a_6_DP.mat');
define_constants;
global MLE_parms;
MLE_parms.Algorithm     = 'MLE_CC_2D_PO';
MLE_parms.units         = 'm';
MLE_parms.Scenario      = 2;
MLE_parms.Tmin          = 0.0*60;
MLE_parms.Tmax          = 15.0*60;
MLE_parms.PRS_model     = 6;
MLE_parms.max_iter      = 25;
MLE_parms.max_srch      = 21;
MLE_parms.Rng_max       = 10000.0;
MLE_parms.Rng_con_flg   = true;
MLE_parms.Rng_con_val   = 5000.0;
MLE_parms.Rng_con_sig   = 5000.0;
MLE_parms.Prob          = 0.90;
MLE_parms.alpha         = 0.01;
MLE_parms.dbug_flag     = false;
MLE_parms.Cavg          = Cavg;
MLE_parms.Zbot          = Zbot;
MLE_parms.Nrev          = Meas(1).Nrev;

indxM = find([Meas.Time] >= MLE_parms.Tmin & [Meas.Time] <= MLE_parms.Tmax);
Meas = Meas(indxM);
indxT = find([Truth.Time] == Meas(end).Time);
Xhat0 = [Truth(indxT).Xtgt; Truth(indxT).Ytgt; Truth(indxT).Ztgt] + [1000; -1000; -50];

% =========================================================================
% FAST VECTORIZED IMPLEMENTATION
% =========================================================================
function [Xhat, Phat, cst_min, iter, t_elapsed] = run_fast_mle(Meas, Xhat0, MLE_parms)
    t_start = tic;
    N = length(Meas);
    Model = MLE_parms.PRS_model;
    Cavg = MLE_parms.Cavg;
    Rng_con_flg = MLE_parms.Rng_con_flg;
    Rng_con_val = MLE_parms.Rng_con_val;
    Rng_con_sig = MLE_parms.Rng_con_sig;

    % 1. Precompute invariant sensor panel positions once for all N pings
    Fpos = zeros(N, 3);
    Mpos = zeros(N, 3);
    Apos = zeros(N, 3);
    TFM = zeros(N, 1);
    TFMsig = zeros(N, 1);
    TMA = zeros(N, 1);
    TMAsig = zeros(N, 1);

    for k = 1:N
        [Fpos(k,:), Mpos(k,:), Apos(k,:)] = ...
            MLE_define_PRS_panel_positions(Model, Meas(k).Xown, Meas(k).Yown, Meas(k).Zown, Meas(k).Senhdg);
        TFM(k) = Meas(k).TFM;
        TFMsig(k) = Meas(k).TFMsig;
        TMA(k) = Meas(k).TMA;
        TMAsig(k) = Meas(k).TMAsig;
    end

    % Fast vectorized cost function
    function [cst, r_fm, r_ma, srgF, srgM, srgA, dF, dM, dA] = calc_cost(X)
        dF = X' - Fpos; % 1x3 - Nx3 = Nx3
        dM = X' - Mpos;
        dA = X' - Apos;
        srgF = sqrt(sum(dF.^2, 2));
        srgM = sqrt(sum(dM.^2, 2));
        srgA = sqrt(sum(dA.^2, 2));

        tau_fm = (srgM - srgF) / Cavg;
        tau_ma = (srgA - srgM) / Cavg;

        r_fm = (TFM - tau_fm) ./ TFMsig;
        r_ma = (TMA - tau_ma) ./ TMAsig;
        cst = sum(r_fm.^2) + sum(r_ma.^2);

        if Rng_con_flg
            rng_c = norm(X);
            r_rng = (Rng_con_val - rng_c) / Rng_con_sig;
            cst = cst + r_rng^2;
        end
    end

    Xhat = Xhat0;
    cst_thrsh = 1.0e-14;
    pos_thrsh = 1.0e-8;
    max_iter = MLE_parms.max_iter;

    alfa_grid = 0.0:0.05:1.0; % Identical line search grid for exact parity
    cst_min = calc_cost(Xhat);

    for iter = 1:max_iter
        % 1. Vectorized Jacobian & Residual
        [~, r_fm, r_ma, srgF, srgM, srgA, dF, dM, dA] = calc_cost(Xhat);

        uF = dF ./ srgF;
        uM = dM ./ srgM;
        uA = dA ./ srgA;

        dtdX_fm = (uM - uF) / Cavg;
        dtdX_ma = (uA - uM) / Cavg;

        J_fm = dtdX_fm ./ TFMsig;
        J_ma = dtdX_ma ./ TMAsig;

        if Rng_con_flg
            rng_c = norm(Xhat);
            J_rng = (Xhat' / rng_c) / Rng_con_sig;
            r_rng = (Rng_con_val - rng_c) / Rng_con_sig;
            Jmtx = [J_fm; J_ma; J_rng];
            Yres = [r_fm; r_ma; r_rng];
        else
            Jmtx = [J_fm; J_ma];
            Yres = [r_fm; r_ma];
        end

        % 2. Fast 3x3 normal equation solve
        % Jmtx is (2N+1) x 3
        [Q, R] = qr(Jmtx, 0);
        Rinv = inv(R);
        Xcor = Rinv * (Q' * Yres);
        Phat = Rinv * Rinv';

        % 3. Line search over grid
        alfa_opt = 0.0;
        cst_cand_min = 1e38;
        for a = alfa_grid
            Xdum = Xhat + a * Xcor;
            cand = calc_cost(Xdum);
            if cand < cst_cand_min
                cst_cand_min = cand;
                alfa_opt = a;
            end
        end

        del_cst = abs(cst_cand_min - cst_min);
        cst_min = cst_cand_min;
        Xhat = Xhat + alfa_opt * Xcor;

        if cst_min < cst_thrsh
            break;
        elseif alfa_opt > 0.0 && del_cst < cst_thrsh && all(abs(Xcor) < pos_thrsh)
            break;
        elseif alfa_opt == 0.0
            break;
        end
    end
    t_elapsed = toc(t_start);
end

% Run and benchmark
[X_fast, P_fast, cst_fast, iter_fast, t_fast] = run_fast_mle(Meas, Xhat0, MLE_parms);

fprintf('=================================================================\n');
fprintf('FAST VECTORIZED MLE BENCHMARK RESULTS:\n');
fprintf('  Fast runtime:      %8.4f s (vs 40.34 s original)\n', t_fast);
fprintf('  Speedup factor:    %8.1fx FASTER\n', 40.3358 / t_fast);
fprintf('  Iterations:        %d\n', iter_fast);
fprintf('  Final Xhat:        [%.4f, %.4f, %.4f] m\n', X_fast(1), X_fast(2), X_fast(3));
fprintf('  Final Cost:        %.6e\n', cst_fast);
fprintf('=================================================================\n');
