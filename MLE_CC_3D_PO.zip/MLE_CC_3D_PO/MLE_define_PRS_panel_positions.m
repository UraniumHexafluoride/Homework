function [PRS_Fpos,PRS_Mpos,PRS_Apos] = ...
    MLE_define_PRS_panel_positions(Model,Xown,Yown,Zown,Senhdg,plot_flag)
%------------------------------------------------------------------
% This function defines the PRS panel/acoustic center positions given
% the ownship position (m) and heading (radians) and using both collinear
% and non-collinear models.
%------------------------------------------------------------------

if nargin == 5
    plot_flag = ~true;
end

define_constants;

if Model == 0
    % Taiwan model - noncollinear
    Ninches = +0.2140;                       % % Pval = .0054 m
    Nmeters = Ninches*cintm;
    Fwd_off = [  0.0000   9.1343   0.0000 ]; % % L1   = 9.1343 m
    Mid_off = [ Nmeters   0.0000   0.0000 ];
    Aft_off = [  0.0000  -9.1399   0.0000 ]; % % L2   = 9.1399 m
elseif Model == 1
    % Collinear panel placement L1 = L2
    Fwd_off = [  0.0000   7.5000   0.0000 ];
    Mid_off = [  0.0000   0.0000   0.0000 ];
    Aft_off = [  0.0000  -7.5000   0.0000 ];
elseif Model == 2
    % Collinear panel placement L1 ~= L2
    Fwd_off = [  0.0000   5.0000   0.0000 ];
    Mid_off = [  0.0000   0.0000   0.0000 ];
    Aft_off = [  0.0000 -10.0000   0.0000 ];
elseif Model == 3
    % Noncollinear L1 = L2, flex in/out by Ninches
    % Note: Positive means mid array is right of fwd and aft
    Ninches = 10.00;
    Nmeters = Ninches*cintm;
    Fwd_off = [  0.0000   7.5000   0.0000 ];
    Mid_off = [ Nmeters   0.0000   0.0000 ];
    Aft_off = [  0.0000  -7.5000   0.0000 ];
elseif Model == 4
    % Noncollinear L1 ~= L2, flex in/out by Ninches
    % Note: Positive means mid array is right of fwd and aft
    Ninches = 10.00;
    Nmeters = Ninches*cintm;
    Fwd_off = [  0.0000   5.0000   0.0000 ];
    Mid_off = [ Nmeters   0.0000   0.0000 ];
    Aft_off = [  0.0000 -10.0000   0.0000 ];
elseif Model == 5
    % Noncollinear L1 ~= L2, flex in/out by Ninches
    % Note: Positive means mid array is right of fwd and aft
    Ninches = 2.00;
    Nmeters = Ninches*cintm;
    Fwd_off = [  0.0000   7.0000   0.0000 ];
    Mid_off = [ Nmeters   0.0000   0.0000 ];
    Aft_off = [  0.0000  -8.0000   0.0000 ];
elseif Model == 6
    % Taiwan Hai Kun class
    % Collinear panel placement L1 = L2
    Ninches = +1.000;
    Nmeters = Ninches*cintm;
    Fwd_off = [  0.0000  18.2882   0.0000 ];
    Mid_off = [ Nmeters   0.0000   0.0000 ];
    Aft_off = [  0.0000 -18.2882   0.0000 ];
end

PRS_Xfwd =  Fwd_off(1)*cos(Senhdg) + Fwd_off(2)*sin(Senhdg);
PRS_Yfwd = -Fwd_off(1)*sin(Senhdg) + Fwd_off(2)*cos(Senhdg);
PRS_Zfwd =  Fwd_off(3);
PRS_Fpos = [ PRS_Xfwd PRS_Yfwd PRS_Zfwd ];

PRS_Xmid =  Mid_off(1)*cos(Senhdg) + Mid_off(2)*sin(Senhdg);
PRS_Ymid = -Mid_off(1)*sin(Senhdg) + Mid_off(2)*cos(Senhdg);
PRS_Zmid =  Mid_off(3);
PRS_Mpos = [ PRS_Xmid PRS_Ymid PRS_Zmid ];

PRS_Xaft =  Aft_off(1)*cos(Senhdg) + Aft_off(2)*sin(Senhdg);
PRS_Yaft = -Aft_off(1)*sin(Senhdg) + Aft_off(2)*cos(Senhdg);
PRS_Zaft =  Aft_off(3);
PRS_Apos = [ PRS_Xaft PRS_Yaft PRS_Zaft ];

PRS_Fpos = PRS_Fpos + [ Xown Yown Zown ];
PRS_Mpos = PRS_Mpos + [ Xown Yown Zown ];
PRS_Apos = PRS_Apos + [ Xown Yown Zown ];

if plot_flag
    [L1,L2,coll_flag] = ...
        plot_PRS_panel_positions(Model,PRS_Fpos,PRS_Mpos,PRS_Apos);
    % prt_rmtx(1,PRS_Fpos,'PRS_Fpos');
    % prt_rmtx(1,PRS_Mpos,'PRS_Mpos');
    % prt_rmtx(1,PRS_Apos,'PRS_Apos');
end

return;
