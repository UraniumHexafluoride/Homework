function [Xhat,Phat,cst_min,Chi_sqrN,Nmsr,conv_flag,vldt_flag] = ...
    MLE_CC_3D_PO_algorithm(Meas,Xhat)
%------------------------------------------------------------------
% This function will generate a maximum likelihood estimate of target
% position given FM time delay and MA time delay measurements over time
% via a Cartesian Coordinate (CC) MLE formulation.
% The state vector Xhat is of the following form:
%    X(1) - target x (East) position (m)
%    X(2) - target y (North) position (m)
%    X(3) - target z (depth) position (m)
%------------------------------------------------------------------
global MLE_parms;

%------------------------------------------------------------------
% Initialization
define_constants;
rng_max = MLE_parms.Rng_max; % maximum range (m)
cst_thrsh = 1.0e-14; % norm cost change threshold for iteration termination
pos_thrsh = 1.0e-8; % position change threshold for iteration termination (m)
nrm_thrsh = 1.0; % norm Chi2 cost threshold for validity check
conv_flag = ~true; % convergence flag (true/false)
vldt_flag = ~true; % validity flag (true/false)
lsh_flag = ~true; % line search plot flag (true/false)
zero = 0; % debug variable

if MLE_parms.dbug_flag
    fid1 = MLE_parms.fid1;
    fid2 = MLE_parms.fid2;
    fprintf(fid2, ' \n');
    fprintf(fid2, ' PRS model: %3d \n', MLE_parms.PRS_model);
end

%------------------------------------------------------------------
% Compute initial cost function
[J0,ChiSqr,Nmsr,Resid] = MLE_CC_3D_PO_cost(Xhat,Meas);
if ChiSqr > 9999.99
    ChiSqr = 9999.99;
end
cst_min = J0;
Chi_sqr_thrsh = chi2inv(1.0 - MLE_parms.alpha, Nmsr - length(Xhat));

%------------------------------------------------------------------
% Debug prints
if MLE_parms.dbug_flag
    fprintf(fid1, ' \n');
    prt_rmtx(fid1, Xhat, ' Xhat');
    fprintf(fid1, ' \n');
    fprintf(fid1, ' J0 %10.6e \n', J0);
    fprintf(fid1, ' \n');
    fprintf(fid2, ' \n');
    if MLE_parms.Rng_con_flg
        fprintf(fid2, ' rng constraint: %7.3f +/- %7.3f Km \n', ...
            MLE_parms.Rng_con_val/1000, MLE_parms.Rng_con_sig/1000);
    end
    fprintf(fid2, ' \n');
    fprintf(fid1, ' Time1: %7.2f Time2: %7.2f (min) \n', ...
        Meas(1).Time/60, Meas(end).Time/60);
    fprintf(fid2, ' Time1: %7.2f Time2: %7.2f (min) \n', ...
        Meas(1).Time/60, Meas(end).Time/60);
    fprintf(fid2, ' iter Xtm Ytm Ztm \n');
    fprintf(fid2, ' alfa Cost ||Xcor|| ChiSqN \n');
    fprintf(fid2, ' %3d %10.2f %10.2f %10.2f \n', ...
        fix(zero), Xhat(1), Xhat(2), Xhat(3));
    if ChiSqr > 9999.99
        ChiSqr = 9999.99;
    end
    fprintf(fid2, ' %8.4f %10.4e %10.4e %7.2f \n', ...
        zero, J0, zero, ChiSqr);
end

%------------------------------------------------------------------
% NLLS Iteration
alfa = linspace(0.0, 1.0, MLE_parms.max_srch);
for iter = 1:MLE_parms.max_iter
    if MLE_parms.dbug_flag
        fprintf(fid1, ' \n');
        fprintf(fid1, '----------------------------------------------------\n');
        fprintf(fid1, ' MLE_CC_3D_PO iteration number %4d \n', iter);
        fprintf(fid2, ' MLE_CC_3D_PO iteration number %4d \n', iter);
        if iter <= 5
            prt_rmtx(fid1, Xhat, 'Xhat');
        end
    end

    %--------------------------------------------------------------
    % Compute Jacobian
    [Jmtx,Yres] = MLE_CC_3D_PO_Jacobian(Xhat,Meas);

    %--------------------------------------------------------------
    % Compute correction vector via QR decomposition
    [Q,R] = qr(Jmtx,0);
    Rinv = inv(R);
    Xcor = Rinv*Q'*Yres;
    Phat = Rinv*Rinv';
    if cond(Jmtx) > 1.e18
        % Set range constraint flag - no observability
        MLE_parms.Rng_con_flg = true;
        if MLE_parms.dbug_flag
            fprintf(fid1, 'MLE_CC_3D_PO_algorithm: No observability -> Rng constraint \n');
        end
    end

    if MLE_parms.dbug_flag && iter <= 5
        prt_rmtx(fid1, Jmtx, 'Jmtx');
        fprintf(fid1, ' cond(Jmtx) = %12.5e \n', cond(Jmtx));
        prt_rmtx(fid1, Yres, 'Yres');
        prt_rmtx(fid1, Xcor, 'Xcor');
    end

    %--------------------------------------------------------------
    % Implement the line search
    if MLE_parms.dbug_flag
        fprintf(fid1, ' \n');
        fprintf(fid1, ' Line Search \n');
        fprintf(fid1, ' alfa cost \n');
    end
    alfa_opt = 0.0;
    cst_min = 1.e38;
    Chi_sqrN = 1.e38;
    clear cst;
    cst = zeros(1, length(alfa));
    for ii = 1:length(alfa)
        Xdum = Xhat + alfa(ii)*Xcor;
        [cst(ii),ChiSqr,Nmsr,Resid] = MLE_CC_3D_PO_cost(Xdum,Meas);
        if ChiSqr > 9999.99
            ChiSqr = 9999.99;
        end
        ChiSqN = ChiSqr;
        if MLE_parms.dbug_flag
            fprintf(fid1, ' %8.5f %12.6e %8.1f %8.1f %8.1f \n', ...
                alfa(ii), cst(ii), Xdum(1), Xdum(2), Xdum(3));
        end
        if cst(ii) < cst_min
            alfa_opt = alfa(ii);
            cst_min = cst(ii);
            Chi_sqrN = ChiSqN;
        end
    end % line search loop

    if lsh_flag
        %----------------------------------------------------------
        % Plot line search results
        figure;
        hold on;
        plot(alfa, cst, 'linestyle', '-', 'linewidth', 2, 'color', 'b');
        plot(alfa(1), cst(1), 'linestyle', 'none', 'marker', 'p', 'markersize', 12, ...
            'markeredgecolor', 'k', 'markerfacecolor', 'g');
        plot(alfa_opt, cst_min, 'linestyle', 'none', 'marker', 'p', 'markersize', 12, ...
            'markeredgecolor', 'k', 'markerfacecolor', 'r');
        ax = axis;
        xtxt = ax(1) + .70*(ax(2) - ax(1));
        ytxt = ax(4) - .12*(ax(4) - ax(3));
        summary = {['Iteration ', int2str(iter)], ...
                   ['Cost_0 ', num2str(cst(1), '%12.4e')], ...
                   ['Cost_f ', num2str(cst_min, '%12.4e')], ...
                   ['\alpha ', num2str(alfa_opt, '%6.3f')]};
        text(xtxt, ytxt, summary, 'FontSize', 10, 'FontWeight', 'bold', 'color', 'k');
        xlabel('\alpha', 'FontSize', 12, 'FontWeight', 'bold');
        ylabel('Cost', 'FontSize', 12, 'FontWeight', 'bold');
        title(remove_char(MLE_parms.Algorithm, '_'), 'FontSize', 12, 'FontWeight', 'bold');
        box on;
        grid on;
        grid minor;
    end

    %--------------------------------------------------------------
    % Update the state vector
    Xhat = Xhat + alfa_opt*Xcor;
    if MLE_parms.dbug_flag
        prt_rmtx(fid1, Xhat, 'Xhat');
    end

    %--------------------------------------------------------------
    % Debug prints
    if MLE_parms.dbug_flag
        fprintf(fid1, ' \n');
        fprintf(fid1, ' alfa_opt %10.6f \n', alfa_opt);
        fprintf(fid1, ' cst_min %10.6e \n', cst_min);
        fprintf(fid2, ' %3d %10.2f %10.2f %10.2f \n', ...
            iter, Xhat(1), Xhat(2), Xhat(3));
        fprintf(fid2, ' %8.4f %10.4e %10.4e %7.2f \n', ...
            alfa_opt, cst_min, norm(Xcor), Chi_sqrN);
    end

    %--------------------------------------------------------------
    % Check for solution validity and algorithm convergence
    del_cst = abs(cst_min - J0);
    J0 = cst_min;
    % Range check
    xrel = Xhat(1) - Meas(end).Xsen;
    yrel = Xhat(2) - Meas(end).Ysen;
    zrel = Xhat(3) - Meas(end).Zsen;
    rng = sqrt(xrel*xrel + yrel*yrel + zrel*zrel);
    if (Chi_sqr_thrsh == 0 && Chi_sqrN < nrm_thrsh) && rng < rng_max
        vldt_flag = true;
    elseif (Chi_sqr_thrsh > 0 && cst_min < Chi_sqr_thrsh) && rng < rng_max
        vldt_flag = true;
    elseif rng > rng_max
        MLE_parms.Rng_con_flg = true;
        if MLE_parms.dbug_flag
            fprintf(fid1, 'MLE_CC_3D_PO_algorithm: rng max -> Rng constraint \n');
        end
    end
    if cst_min < cst_thrsh
        conv_flag = true;
        break;
    elseif alfa_opt > 0.0 && del_cst < cst_thrsh && ...
            Xcor(1) < pos_thrsh && Xcor(2) < pos_thrsh && Xcor(3) < pos_thrsh
        conv_flag = true;
        break;
    elseif alfa_opt == 0.0
        break;
    end
end % NLLS iteration loop

if MLE_parms.dbug_flag
    if conv_flag
        fprintf(fid2, ' convergence \n');
    else
        fprintf(fid2, ' no convergence \n');
    end
    if vldt_flag
        fprintf(fid2, ' solution valid \n');
    else
        fprintf(fid2, ' solution invalid \n');
    end
    fprintf(fid2, ' Length(Meas) %4d \n', length(Meas));
    fprintf(fid2, ' Chi2 value %8.2f \n', cst_min);
    fprintf(fid2, ' Chi2 thresh %8.2f \n', Chi_sqr_thrsh);
    prt_rmtx(fid1, Xhat, 'Xhat');
end

%------------------------------------------------------------------
% Compute range, bearing and depth variance wrt origin
[rng,brg,dpt,rsig,bsig,zsig] = ...
    MLE_CC_3D_PO_soln(Meas(end).Xown, Meas(end).Yown, Xhat, Phat, MLE_parms.Prob);

return;
