function prt_rmtx(fid,Rmtx,label)
%------------------------------------------------------------------
% This subroutine prints out the real matrix Rmtx identified by label.
%------------------------------------------------------------------

Nr = ceil(log10(max(max(abs(Rmtx))))) + 2;
Nl = 10 - Nr;
if Nl > 0 && Nl < Nr+Nl
    fmt_str = [ '%+' int2str(Nr+Nl+1) '.' int2str(Nl+1) 'f' ];
else
    fmt_str = [ ' %12.4e ' ];
end
[M,N] = size(Rmtx);

fprintf(fid,'\n');
fprintf(fid,' %-20s [ %3d x %3d ] \n',label,M,N);
if N <= 10 && isreal(Rmtx)
    for ii = 1:M
        fprintf(fid,' ');
        for jj = 1:N
            fprintf(fid,fmt_str,Rmtx(ii,jj));
        end
        fprintf(fid,'\n');
    end
else
    fprintf(fid,' Matrix too big, %-2d x %-2d \n',size(Rmtx));
end
fprintf(fid,'\n');

return;
