% generate_test_scenario.m
% Generates synthetic scenario data Meas_CASPRSTWD_10a_6_DP.mat
% for Test_MLE_CC_3D_PO.

clearvars;
close all;

define_constants;
global MLE_parms;

% Sound speed and ocean bottom
Cavg = 1500.0;     % sound speed (m/s)
Zbot = 1000.0;     % ocean bottom depth (m)
PRS_model = 6;     % Hai Kun class (collinear, L1=L2=18.2882m, Ninches=1.0)

MLE_parms.Cavg = Cavg;
MLE_parms.PRS_model = PRS_model;
MLE_parms.units = 'm';

% Stationary target position
Xtgt = 3000.0;     % target x (m)
Ytgt = 4000.0;     % target y (m) (Range ~ 5000 m, bearing ~ 036.87 deg)
Ztgt = 150.0;      % target depth (m)

% Time settings: 0 to 30 minutes, dt = 5 seconds
t = (0:5:1800)';
Npts = length(t);

% Ownship motion
% Speed ~ 6 knots (approx 3.086 m/s)
spd = 6.0 * ckts;
% Ownship starts at origin, depth 50 m
% Conducts a 2-leg maneuver:
% Leg 1 (0 to 15 min): heading 060 deg
% Leg 2 (15 to 30 min): heading 120 deg
Xown = zeros(Npts, 1);
Yown = zeros(Npts, 1);
Zown = 50.0 * ones(Npts, 1);
Senhdg = zeros(Npts, 1);

Xcurr = 0.0;
Ycurr = 0.0;
for k = 1:Npts
    if t(k) <= 900.0
        hdg = 60.0 * dtr;
    else
        hdg = 120.0 * dtr;
    end
    if k > 1
        dt = t(k) - t(k-1);
        Xcurr = Xcurr + spd * sin(hdg) * dt;
        Ycurr = Ycurr + spd * cos(hdg) * dt;
    end
    Xown(k) = Xcurr;
    Yown(k) = Ycurr;
    Senhdg(k) = hdg;
end

% Measurement standard deviations
TFMsig = 1.0e-6;   % 1 microsecond
TMAsig = 1.0e-6;   % 1 microsecond

% Preallocate structs
Meas = struct('Time', cell(Npts, 1), ...
              'Xown', cell(Npts, 1), ...
              'Yown', cell(Npts, 1), ...
              'Zown', cell(Npts, 1), ...
              'Xsen', cell(Npts, 1), ...
              'Ysen', cell(Npts, 1), ...
              'Zsen', cell(Npts, 1), ...
              'Senhdg', cell(Npts, 1), ...
              'Nrev', cell(Npts, 1), ...
              'TFM', cell(Npts, 1), ...
              'TFMsig', cell(Npts, 1), ...
              'TMA', cell(Npts, 1), ...
              'TMAsig', cell(Npts, 1));

Truth = struct('Time', cell(Npts, 1), ...
               'Xtgt', cell(Npts, 1), ...
               'Ytgt', cell(Npts, 1), ...
               'Ztgt', cell(Npts, 1));

rng(42); % Reproducible random noise

for k = 1:Npts
    Truth(k).Time = t(k);
    Truth(k).Xtgt = Xtgt;
    Truth(k).Ytgt = Ytgt;
    Truth(k).Ztgt = Ztgt;

    Meas(k).Time = t(k);
    Meas(k).Xown = Xown(k);
    Meas(k).Yown = Yown(k);
    Meas(k).Zown = Zown(k);
    Meas(k).Xsen = Xown(k);
    Meas(k).Ysen = Yown(k);
    Meas(k).Zsen = Zown(k);
    Meas(k).Senhdg = Senhdg(k);
    Meas(k).Nrev = 0; % Direct Path

    % Compute true PRS time delays
    [tau_fm, tau_ma, ~, ~, ~, ~] = ...
        MLE_compute_PRS_time_delays(Xown(k), Yown(k), Zown(k), Senhdg(k), ...
                                    Xtgt, Ytgt, Ztgt, 0, Zbot);

    % Add noise
    Meas(k).TFM = tau_fm + 0.05 * TFMsig * randn;
    Meas(k).TFMsig = TFMsig;
    Meas(k).TMA = tau_ma + 0.05 * TMAsig * randn;
    Meas(k).TMAsig = TMAsig;
end

% Save MAT-file
file_name = 'Meas_CASPRSTWD_10a_6_DP.mat';
save(file_name, 'Meas', 'Truth', 'Cavg', 'Zbot');
fprintf('Successfully generated %s with %d measurements.\n', file_name, Npts);
